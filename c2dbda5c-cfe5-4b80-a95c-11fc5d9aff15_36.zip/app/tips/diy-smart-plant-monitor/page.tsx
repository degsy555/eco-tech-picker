'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import NewsletterSignup from '@/components/NewsletterSignup';
import Link from 'next/link';

export default function DIYSmartPlantMonitorPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="relative bg-gradient-to-r from-emerald-50 to-teal-50 py-20">
          <div 
            className="absolute inset-0 bg-cover bg-center opacity-10"
            style={{
              backgroundImage: `url('https://readdy.ai/api/search-image?query=DIY%20smart%20plant%20monitoring%20system%20with%20sensors%2C%20arduino%2C%20plants%2C%20electronic%20components%2C%20sustainable%20gardening%20technology%2C%20green%20IoT%20project&width=1200&height=600&seq=diy-plant-hero-1&orientation=landscape')`
            }}
          ></div>
          <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <div className="inline-flex items-center space-x-2 bg-emerald-100 text-emerald-600 px-4 py-2 rounded-full text-sm font-medium mb-4">
                <i className="ri-tools-line"></i>
                <span>DIY Projects</span>
              </div>
              <h1 className="text-5xl font-bold text-gray-900 mb-6">
                DIY Smart Plant Monitor
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Build an automated plant monitoring system that tracks soil moisture, light levels, 
                and temperature to keep your plants healthy and thriving.
              </p>
              <div className="flex items-center justify-center space-x-6 text-sm text-gray-500">
                <span className="flex items-center space-x-1">
                  <i className="ri-time-line"></i>
                  <span>12 min read</span>
                </span>
                <span className="flex items-center space-x-1">
                  <i className="ri-user-line"></i>
                  <span>EcoTechPicks Team</span>
                </span>
                <span className="flex items-center space-x-1">
                  <i className="ri-calendar-line"></i>
                  <span>Updated Dec 2024</span>
                </span>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="prose prose-lg max-w-none">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-6 mb-8">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-amber-600 rounded-full flex items-center justify-center">
                    <i className="ri-lightbulb-line text-white text-sm"></i>
                  </div>
                  <div>
                    <h3 className="text-amber-800 font-semibold mb-1">Project Overview</h3>
                    <p className="text-amber-700 text-sm">
                      Difficulty: Intermediate • Time: 4-6 hours • Cost: $40-70 • Skills: Basic electronics, Arduino programming
                    </p>
                  </div>
                </div>
              </div>

              <h2 className="text-2xl font-bold text-gray-900 mb-4">What You'll Build</h2>
              <p className="text-gray-700 mb-6">
                This project creates a smart monitoring system that continuously tracks your plant's environment 
                and can alert you when conditions aren't optimal. The system measures soil moisture, ambient 
                light, and temperature, displaying readings on an LCD screen and optionally sending alerts.
              </p>

              <h2 className="text-2xl font-bold text-gray-900 mb-4">Materials Needed</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-900 mb-3">Electronics</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>Arduino Uno or Nano</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>Soil Moisture Sensor</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>DHT22 Temperature/Humidity Sensor</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>Light Dependent Resistor (LDR)</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>16x2 LCD Display</span>
                    </li>
                  </ul>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-900 mb-3">Additional Components</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>Breadboard or PCB</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>Jumper Wires</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>10kΩ Resistor</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>Piezo Buzzer (optional)</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>Project Enclosure</span>
                    </li>
                  </ul>
                </div>
              </div>

              <h2 className="text-2xl font-bold text-gray-900 mb-4">Circuit Assembly</h2>
              
              <div className="space-y-8">
                <div className="border-l-4 border-emerald-600 pl-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Step 1: Connect the LCD Display</h3>
                  <p className="text-gray-700 mb-4">
                    Connect the LCD to the Arduino using I2C communication to minimize wire usage. 
                    This typically requires only 4 wires: VCC, GND, SDA, and SCL.
                  </p>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <p className="text-blue-700 text-sm">
                      <strong>Connection:</strong> VCC → 5V, GND → GND, SDA → A4, SCL → A5
                    </p>
                  </div>
                </div>

                <div className="border-l-4 border-emerald-600 pl-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Step 2: Wire the Soil Moisture Sensor</h3>
                  <p className="text-gray-700 mb-4">
                    Connect the soil moisture sensor to an analog pin. The sensor outputs a voltage 
                    proportional to soil moisture levels - higher voltage means drier soil.
                  </p>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <p className="text-blue-700 text-sm">
                      <strong>Connection:</strong> VCC → 5V, GND → GND, A0 → Arduino A0
                    </p>
                  </div>
                </div>

                <div className="border-l-4 border-emerald-600 pl-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Step 3: Add Temperature and Light Sensors</h3>
                  <p className="text-gray-700 mb-4">
                    Connect the DHT22 sensor to a digital pin and the LDR to an analog pin with a 
                    10kΩ pull-down resistor to create a voltage divider circuit.
                  </p>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <p className="text-blue-700 text-sm">
                      <strong>DHT22:</strong> VCC → 5V, GND → GND, Data → D2<br/>
                      <strong>LDR:</strong> One end → 5V, Other end → A1 and 10kΩ resistor to GND
                    </p>
                  </div>
                </div>
              </div>

              <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-12">Programming the Arduino</h2>
              
              <div className="bg-gray-900 text-gray-100 rounded-lg p-6 mb-6 overflow-x-auto">
                <pre className="text-sm">
{`#include <LiquidCrystal_I2C.h>
#include <DHT.h>

#define SOIL_PIN A0
#define LIGHT_PIN A1
#define DHT_PIN 2
#define DHT_TYPE DHT22

LiquidCrystal_I2C lcd(0x27, 16, 2);
DHT dht(DHT_PIN, DHT_TYPE);

void setup() {
  Serial.begin(9600);
  lcd.init();
  lcd.backlight();
  dht.begin();
  
  lcd.setCursor(0, 0);
  lcd.print("Plant Monitor");
  lcd.setCursor(0, 1);
  lcd.print("Starting...");
  delay(2000);
}

void loop() {
  int soilValue = analogRead(SOIL_PIN);
  int lightValue = analogRead(LIGHT_PIN);
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();
  
  // Convert readings to percentages
  int soilPercent = map(soilValue, 0, 1023, 100, 0);
  int lightPercent = map(lightValue, 0, 1023, 0, 100);
  
  // Display on LCD
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Soil:" + String(soilPercent) + "% T:" + String(temperature, 1));
  lcd.setCursor(0, 1);
  lcd.print("Light:" + String(lightPercent) + "% H:" + String(humidity, 1));
  
  // Check for alerts
  if (soilPercent < 20) {
    // Water needed alert
    tone(8, 1000, 500); // Buzzer on pin 8
  }
  
  delay(5000); // Update every 5 seconds
}`}
                </pre>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 mt-8">
                <h3 className="text-emerald-800 font-semibold mb-2">Features of Your Monitor</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="font-semibold text-emerald-700">Real-time Monitoring</div>
                    <div className="text-emerald-600">Continuous sensor readings</div>
                  </div>
                  <div>
                    <div className="font-semibold text-emerald-700">LCD Display</div>
                    <div className="text-emerald-600">Easy-to-read plant status</div>
                  </div>
                  <div>
                    <div className="font-semibold text-emerald-700">Alert System</div>
                    <div className="text-emerald-600">Buzzer for watering reminders</div>
                  </div>
                  <div>
                    <div className="font-semibold text-emerald-700">Data Logging</div>
                    <div className="text-emerald-600">Serial output for recording</div>
                  </div>
                </div>
              </div>

              <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-12">Calibration and Setup</h2>
              
              <div className="space-y-6">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-900 mb-2">Soil Sensor Calibration</h3>
                  <p className="text-gray-700 text-sm mb-2">
                    Test the sensor in both dry and wet soil to establish baseline readings for accurate percentage calculations.
                  </p>
                  <div className="text-xs text-gray-600">
                    Dry soil: ~1000+ • Wet soil: ~300-400 • Adjust map() function accordingly
                  </div>
                </div>
                
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-900 mb-2">Light Sensor Setup</h3>
                  <p className="text-gray-700 text-sm mb-2">
                    Position the LDR where it can accurately measure the light your plant receives throughout the day.
                  </p>
                  <div className="text-xs text-gray-600">
                    Dark: ~0-100 • Bright: ~800-1000 • Adjust thresholds for your environment
                  </div>
                </div>
              </div>

              <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-12">Enhancement Ideas</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-emerald-600 rounded-full flex items-center justify-center">
                      <i className="ri-wifi-line text-white text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">WiFi Connectivity</h4>
                      <p className="text-gray-700 text-sm">Add ESP32 for remote monitoring via smartphone app</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-emerald-600 rounded-full flex items-center justify-center">
                      <i className="ri-database-line text-white text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Data Logging</h4>
                      <p className="text-gray-700 text-sm">Add SD card module to record long-term plant health data</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-emerald-600 rounded-full flex items-center justify-center">
                      <i className="ri-drop-line text-white text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Auto-Watering</h4>
                      <p className="text-gray-700 text-sm">Connect water pump for automated irrigation system</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-emerald-600 rounded-full flex items-center justify-center">
                      <i className="ri-sun-line text-white text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Solar Power</h4>
                      <p className="text-gray-700 text-sm">Add solar panel and battery for outdoor use</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-6">
                  Build More Smart Solutions
                </h2>
                <p className="text-gray-600 mb-8">
                  This plant monitor is just the beginning. Explore more DIY projects that combine 
                  technology with sustainability to create smarter, greener living spaces.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link href="/tips" className="bg-emerald-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer text-center">
                    More DIY Projects
                  </Link>
                  <Link href="/submit-tip" className="border border-emerald-600 text-emerald-600 px-6 py-3 rounded-lg font-semibold hover:bg-emerald-50 transition-colors whitespace-nowrap cursor-pointer text-center">
                    Share Your Build
                  </Link>
                </div>
              </div>
              <div>
                <NewsletterSignup />
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
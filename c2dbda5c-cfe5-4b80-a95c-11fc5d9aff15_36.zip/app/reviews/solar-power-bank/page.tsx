'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function SolarPowerBankReview() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="py-16 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <Link href="/reviews" className="text-emerald-600 hover:text-emerald-700 cursor-pointer">
                ← Back to Reviews
              </Link>
            </div>
            
            <article>
              <header className="mb-8">
                <div className="flex items-center space-x-4 mb-4">
                  <span className="bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full text-sm font-medium">
                    Solar Energy
                  </span>
                  <span className="text-gray-500">March 15, 2024</span>
                  <span className="text-gray-500">by Sarah Green</span>
                </div>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                  Solar Power Bank 20000mAh - Endless Energy for Your Adventures
                </h1>
                <div className="flex items-center space-x-2 mb-6">
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <i key={i} className="ri-star-fill text-yellow-400 text-lg"></i>
                    ))}
                  </div>
                  <span className="text-gray-600 font-medium">5.0/5</span>
                </div>
              </header>
              
              <div className="mb-8">
                <img 
                  src="https://readdy.ai/api/search-image?query=high-quality%20solar%20power%20bank%2020000mAh%20with%20multiple%20charging%20ports%2C%20outdoor%20camping%20setting%20with%20tent%20and%20mountains%2C%20professional%20product%20photography%2C%20eco-friendly%20portable%20charger%2C%20rugged%20design&width=800&height=500&seq=solar-bank-detail-1&orientation=landscape"
                  alt="Solar Power Bank 20000mAh"
                  className="w-full h-96 object-cover object-top rounded-lg shadow-lg"
                />
              </div>
              
              <div className="prose prose-lg max-w-none">
                <p className="text-xl text-gray-600 mb-6">
                  After testing this solar power bank extensively over three months of camping trips, 
                  hiking adventures, and daily use, I can confidently say it's revolutionized how I stay 
                  connected while reducing my carbon footprint.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Key Features</h2>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>20,000mAh capacity charges most phones 4-6 times</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>High-efficiency solar panels with 22% conversion rate</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>IP67 waterproof rating for outdoor adventures</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>Dual USB-A and USB-C ports for multiple devices</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>Built-in LED flashlight with SOS mode</span>
                  </li>
                </ul>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Performance Testing</h2>
                <p className="mb-4">
                  During our testing period, the solar charging capability impressed us most. In direct 
                  sunlight, the power bank gained approximately 25% charge per day, which is remarkable 
                  for a device this size. The traditional charging via USB-C takes about 6 hours from 
                  empty to full.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Environmental Impact</h2>
                <p className="mb-4">
                  What sets this power bank apart is its genuine commitment to sustainability. The 
                  manufacturer uses recycled materials in the casing and packaging, and for every 
                  unit sold, they plant a tree through their partnership with reforestation programs.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Pros and Cons</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-green-800 mb-2">Pros</h3>
                    <ul className="text-green-700 space-y-1 text-sm">
                      <li>• Excellent solar charging efficiency</li>
                      <li>• Durable, waterproof construction</li>
                      <li>• Multiple charging options</li>
                      <li>• Built-in safety features</li>
                      <li>• Eco-friendly materials</li>
                    </ul>
                  </div>
                  <div className="bg-red-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-red-800 mb-2">Cons</h3>
                    <ul className="text-red-700 space-y-1 text-sm">
                      <li>• Heavier than non-solar alternatives</li>
                      <li>• Solar charging slower in cloudy weather</li>
                      <li>• Higher upfront cost</li>
                    </ul>
                  </div>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Final Verdict</h2>
                <p className="mb-6">
                  The Solar Power Bank 20000mAh earns our highest recommendation for anyone serious 
                  about sustainable energy solutions. While it may cost more upfront, the long-term 
                  benefits to both your wallet and the environment make it an excellent investment.
                </p>
                
                <div className="bg-emerald-50 p-6 rounded-lg mb-8">
                  <h3 className="font-semibold text-emerald-800 mb-2">Our Rating: 5/5 Stars</h3>
                  <p className="text-emerald-700">
                    "A game-changing device that perfectly balances performance, sustainability, and 
                    reliability. Essential for eco-conscious adventurers and emergency preparedness."
                  </p>
                </div>
              </div>
            </article>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
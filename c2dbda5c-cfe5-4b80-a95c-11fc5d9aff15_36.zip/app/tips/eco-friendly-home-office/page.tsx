'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function EcoFriendlyHomeOfficePage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="py-16 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <Link href="/tips" className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                ← Back to Tips
              </Link>
            </div>
            
            <article>
              <header className="mb-8">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
                    <i className="ri-plant-line text-white text-xl"></i>
                  </div>
                  <span className="bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full text-sm font-medium">
                    Workspace
                  </span>
                </div>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                  Building an Eco-Friendly Home Office
                </h1>
                <div className="flex items-center space-x-4 text-gray-600">
                  <span className="flex items-center space-x-1">
                    <i className="ri-time-line"></i>
                    <span>6 min read</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <i className="ri-calendar-line"></i>
                    <span>Updated March 2024</span>
                  </span>
                </div>
              </header>
              
              <div className="prose prose-lg max-w-none">
                <img 
                  src="https://readdy.ai/api/search-image?query=eco-friendly%20home%20office%20workspace%20with%20natural%20wood%20desk%2C%20green%20plants%2C%20energy%20efficient%20LED%20lighting%2C%20sustainable%20materials%2C%20solar%20charger%2C%20minimal%20waste%2C%20organized%20green%20workspace&width=800&height=400&seq=eco-office-1&orientation=landscape"
                  alt="Eco-friendly home office"
                  className="rounded-lg shadow-lg mb-8 w-full h-96 object-cover object-top"
                />
                
                <p className="text-xl text-gray-600 mb-8">
                  Create a productive workspace that's kind to the planet. With thoughtful choices in equipment, materials, and habits, your home office can be both efficient and environmentally responsible.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Sustainable Furniture and Materials</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Choose Sustainable Materials</h3>
                <p className="text-gray-600 mb-4">
                  When setting up your office, prioritize furniture made from sustainable materials:
                </p>
                
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• <strong>Bamboo:</strong> Fast-growing, renewable, and naturally antimicrobial</li>
                  <li>• <strong>Reclaimed wood:</strong> Reduces demand for new timber</li>
                  <li>• <strong>Recycled metal:</strong> Durable and infinitely recyclable</li>
                  <li>• <strong>Cork:</strong> Renewable bark that regrows every 9 years</li>
                  <li>• <strong>Certified wood:</strong> Look for FSC (Forest Stewardship Council) certification</li>
                </ul>
                
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-emerald-800 mb-3">Eco-Friendly Furniture Brands:</h3>
                  <ul className="text-emerald-700 space-y-2">
                    <li>• IKEA (renewable materials, circular design)</li>
                    <li>• Herman Miller (Cradle to Cradle certified)</li>
                    <li>• Steelcase (carbon neutral operations)</li>
                    <li>• Haworth (GREENGUARD certified)</li>
                    <li>• Humanscale (net positive manufacturing)</li>
                  </ul>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Energy-Efficient Equipment</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Computer and Electronics</h3>
                <p className="text-gray-600 mb-4">
                  Choose ENERGY STAR certified equipment that uses less power:
                </p>
                
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• Laptops use 50-80% less energy than desktop computers</li>
                  <li>• LED monitors consume 25% less energy than LCD screens</li>
                  <li>• All-in-one printers reduce overall energy consumption</li>
                  <li>• Solid-state drives (SSDs) use less power than traditional hard drives</li>
                </ul>
                
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-blue-800 mb-3">Power Management Settings:</h3>
                  <ul className="text-blue-700 space-y-2">
                    <li>• Set monitors to sleep after 10-15 minutes</li>
                    <li>• Enable hibernation for computers after 30 minutes</li>
                    <li>• Use advanced power management features</li>
                    <li>• Adjust screen brightness to comfortable levels</li>
                    <li>• Unplug chargers when not in use</li>
                  </ul>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Lighting Solutions</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Maximize Natural Light</h3>
                <p className="text-gray-600 mb-4">
                  Position your desk near a window to take advantage of natural light:
                </p>
                
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• Reduces eye strain and improves mood</li>
                  <li>• Minimizes need for artificial lighting during day</li>
                  <li>• Use light-colored walls and surfaces to reflect light</li>
                  <li>• Install adjustable blinds to control glare</li>
                </ul>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">LED Task Lighting</h3>
                <p className="text-gray-600 mb-6">
                  When artificial light is needed, choose LED fixtures with adjustable brightness and color temperature.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Air Quality and Plants</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Natural Air Purification</h3>
                <p className="text-gray-600 mb-4">
                  Indoor plants not only improve air quality but also boost productivity and reduce stress:
                </p>
                
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-emerald-800 mb-3">Best Office Plants:</h3>
                  <ul className="text-emerald-700 space-y-2">
                    <li>• <strong>Spider Plant:</strong> Removes formaldehyde and xylene</li>
                    <li>• <strong>Peace Lily:</strong> Filters ammonia and benzene</li>
                    <li>• <strong>Snake Plant:</strong> Produces oxygen at night</li>
                    <li>• <strong>Pothos:</strong> Low maintenance, removes indoor pollutants</li>
                    <li>• <strong>Rubber Plant:</strong> Excellent for removing formaldehyde</li>
                  </ul>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Paperless Office Strategies</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Digital Document Management</h3>
                <p className="text-gray-600 mb-4">
                  Reduce paper consumption with digital alternatives:
                </p>
                
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• Use cloud storage for document sharing</li>
                  <li>• Electronic signatures for contracts</li>
                  <li>• Digital note-taking apps instead of paper</li>
                  <li>• Email receipts and invoices</li>
                  <li>• Digital business cards</li>
                </ul>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">When Printing is Necessary</h3>
                <ul className="text-gray-600 mb-8 space-y-2">
                  <li>• Use recycled paper (30% post-consumer content minimum)</li>
                  <li>• Print double-sided whenever possible</li>
                  <li>• Choose eco-friendly ink cartridges</li>
                  <li>• Reuse single-sided paper for drafts</li>
                  <li>• Recycle all paper waste properly</li>
                </ul>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Sustainable Office Supplies</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-emerald-800 mb-3">Eco-Friendly Supplies:</h3>
                    <ul className="text-emerald-700 space-y-2">
                      <li>• Refillable pens and markers</li>
                      <li>• Recycled notebooks and paper</li>
                      <li>• Biodegradable cleaning products</li>
                      <li>• Bamboo or recycled desk organizers</li>
                      <li>• Reusable coffee cups and water bottles</li>
                    </ul>
                  </div>
                  
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-blue-800 mb-3">Avoid These Items:</h3>
                    <ul className="text-blue-700 space-y-2">
                      <li>• Single-use plastic organizers</li>
                      <li>• Disposable coffee pods</li>
                      <li>• Non-recyclable packaging</li>
                      <li>• Toxic cleaning chemicals</li>
                      <li>• Styrofoam containers</li>
                    </ul>
                  </div>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Energy and Water Conservation</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Smart Power Management</h3>
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• Use power strips to eliminate phantom loads</li>
                  <li>• Invest in a UPS (Uninterruptible Power Supply) to prevent power waste</li>
                  <li>• Consider solar chargers for small devices</li>
                  <li>• Use programmable thermostats for climate control</li>
                </ul>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Water Conservation</h3>
                <ul className="text-gray-600 mb-8 space-y-2">
                  <li>• Use a water filter instead of bottled water</li>
                  <li>• Install low-flow fixtures in nearby bathrooms</li>
                  <li>• Collect rainwater for watering plants</li>
                  <li>• Choose drought-resistant plants</li>
                </ul>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Waste Reduction Strategies</h2>
                
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-yellow-800 mb-3">The 5 R's of Waste Reduction:</h3>
                  <ol className="text-yellow-700 space-y-2">
                    <li>1. <strong>Refuse:</strong> Say no to unnecessary items</li>
                    <li>2. <strong>Reduce:</strong> Minimize consumption</li>
                    <li>3. <strong>Reuse:</strong> Find new purposes for items</li>
                    <li>4. <strong>Recycle:</strong> Properly dispose of materials</li>
                    <li>5. <strong>Rot:</strong> Compost organic waste</li>
                  </ol>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Measuring Your Impact</h2>
                
                <p className="text-gray-600 mb-6">
                  Track your office's environmental impact with these simple metrics:
                </p>
                
                <ul className="text-gray-600 mb-8 space-y-2">
                  <li>• Monthly electricity usage (kWh)</li>
                  <li>• Paper consumption (sheets per month)</li>
                  <li>• Waste generation (bags per week)</li>
                  <li>• Water usage (if applicable)</li>
                  <li>• Carbon footprint calculations</li>
                </ul>
                
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-800 mb-3">Expected Benefits:</h3>
                  <p className="text-gray-700 mb-4">
                    An eco-friendly home office can reduce your environmental impact by 30-50% while often saving money on utilities and supplies. Plus, you'll enjoy better air quality and a more pleasant workspace.
                  </p>
                  <Link href="/tips" className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                    → Explore More Workspace Tips
                  </Link>
                </div>
              </div>
            </article>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
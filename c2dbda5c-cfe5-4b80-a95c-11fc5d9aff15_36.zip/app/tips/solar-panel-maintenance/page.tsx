'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function SolarPanelMaintenancePage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="py-16 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <Link href="/tips" className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                ← Back to Tips
              </Link>
            </div>
            
            <article>
              <header className="mb-8">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
                    <i className="ri-sun-line text-white text-xl"></i>
                  </div>
                  <span className="bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full text-sm font-medium">
                    Solar Energy
                  </span>
                </div>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                  Solar Panel Maintenance for Maximum Efficiency
                </h1>
                <div className="flex items-center space-x-4 text-gray-600">
                  <span className="flex items-center space-x-1">
                    <i className="ri-time-line"></i>
                    <span>3 min read</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <i className="ri-calendar-line"></i>
                    <span>Updated March 2024</span>
                  </span>
                </div>
              </header>
              
              <div className="prose prose-lg max-w-none">
                <img 
                  src="https://readdy.ai/api/search-image?query=solar%20panels%20being%20cleaned%20on%20residential%20rooftop%20with%20water%20and%20soft%20brush%2C%20maintenance%20worker%20in%20safety%20gear%2C%20blue%20sky%20background%2C%20clean%20efficient%20solar%20installation&width=800&height=400&seq=solar-maintenance-1&orientation=landscape"
                  alt="Solar panel maintenance"
                  className="rounded-lg shadow-lg mb-8 w-full h-96 object-cover object-top"
                />
                
                <p className="text-xl text-gray-600 mb-8">
                  Proper maintenance is crucial for keeping your solar panels operating at peak efficiency. With regular care, you can maximize energy production and extend the lifespan of your solar investment.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Why Solar Panel Maintenance Matters</h2>
                
                <p className="text-gray-600 mb-6">
                  Dirty or poorly maintained solar panels can lose 15-25% of their efficiency. Regular maintenance ensures optimal performance and can prevent costly repairs down the line.
                </p>
                
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-emerald-800 mb-3">Key Benefits of Regular Maintenance:</h3>
                  <ul className="text-emerald-700 space-y-2">
                    <li>• Maintains 95%+ efficiency rating</li>
                    <li>• Extends system lifespan by 5-10 years</li>
                    <li>• Prevents warranty voiding</li>
                    <li>• Maximizes return on investment</li>
                  </ul>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Essential Maintenance Tasks</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">1. Regular Cleaning</h3>
                <p className="text-gray-600 mb-4">
                  Clean your panels every 3-6 months, or more frequently if you live in a dusty area or have trees nearby.
                </p>
                
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
                  <h4 className="text-lg font-semibold text-blue-800 mb-3">Safe Cleaning Steps:</h4>
                  <ol className="text-blue-700 space-y-2">
                    <li>1. Turn off your solar system at the inverter</li>
                    <li>2. Use a soft brush or squeegee with soapy water</li>
                    <li>3. Rinse thoroughly with clean water</li>
                    <li>4. Avoid harsh chemicals or abrasive materials</li>
                    <li>5. Clean during cooler parts of the day</li>
                  </ol>
                </div>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">2. Visual Inspections</h3>
                <p className="text-gray-600 mb-4">
                  Perform monthly visual inspections to check for:
                </p>
                
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• Cracks or damage to panel surfaces</li>
                  <li>• Loose or corroded connections</li>
                  <li>• Pest damage or nesting</li>
                  <li>• Shading from new growth or debris</li>
                  <li>• Wear on mounting hardware</li>
                </ul>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">3. Performance Monitoring</h3>
                <p className="text-gray-600 mb-6">
                  Use your system's monitoring app to track daily energy production. Look for sudden drops in performance that might indicate issues.
                </p>
                
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-yellow-800 mb-3">Safety Warning:</h3>
                  <p className="text-yellow-700">
                    Never attempt to clean or inspect roof-mounted panels yourself. Always hire qualified professionals for rooftop maintenance to avoid injury and system damage.
                  </p>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Seasonal Maintenance Schedule</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Spring (March-May)</h3>
                <ul className="text-gray-600 mb-4 space-y-2">
                  <li>• Deep cleaning after winter</li>
                  <li>• Check for winter damage</li>
                  <li>• Trim nearby vegetation</li>
                  <li>• Inspect mounting hardware</li>
                </ul>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Summer (June-August)</h3>
                <ul className="text-gray-600 mb-4 space-y-2">
                  <li>• Monitor performance during peak season</li>
                  <li>• Check for heat-related issues</li>
                  <li>• Clean more frequently if dusty</li>
                  <li>• Ensure proper ventilation</li>
                </ul>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Fall (September-November)</h3>
                <ul className="text-gray-600 mb-4 space-y-2">
                  <li>• Remove fallen leaves and debris</li>
                  <li>• Prepare for winter weather</li>
                  <li>• Check drain holes and gutters</li>
                  <li>• Schedule professional inspection</li>
                </ul>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Winter (December-February)</h3>
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• Monitor for snow accumulation</li>
                  <li>• Check for ice damage</li>
                  <li>• Ensure panels are not blocked</li>
                  <li>• Review annual performance data</li>
                </ul>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Common Issues and Solutions</h2>
                
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-gray-800 mb-3">Troubleshooting Guide:</h3>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-gray-900">Reduced Energy Production</h4>
                      <p className="text-gray-600 text-sm">Check for shading, dirt buildup, or damaged panels</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Hot Spots on Panels</h4>
                      <p className="text-gray-600 text-sm">May indicate cell damage - contact professional immediately</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Inverter Errors</h4>
                      <p className="text-gray-600 text-sm">Check connections and reset if needed, call technician for persistent issues</p>
                    </div>
                  </div>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Professional vs. DIY Maintenance</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-emerald-800 mb-3">DIY Tasks:</h3>
                    <ul className="text-emerald-700 space-y-2">
                      <li>• Ground-level cleaning</li>
                      <li>• Visual monitoring</li>
                      <li>• Performance tracking</li>
                      <li>• Basic troubleshooting</li>
                    </ul>
                  </div>
                  
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-blue-800 mb-3">Professional Services:</h3>
                    <ul className="text-blue-700 space-y-2">
                      <li>• Rooftop cleaning</li>
                      <li>• Electrical inspections</li>
                      <li>• Hardware tightening</li>
                      <li>• System repairs</li>
                    </ul>
                  </div>
                </div>
                
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-800 mb-3">Maintenance Investment:</h3>
                  <p className="text-gray-700 mb-4">
                    Budget $150-300 annually for professional maintenance. This investment typically pays for itself through improved efficiency and extended system life.
                  </p>
                  <Link href="/tips" className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                    → Explore More Solar Tips
                  </Link>
                </div>
              </div>
            </article>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
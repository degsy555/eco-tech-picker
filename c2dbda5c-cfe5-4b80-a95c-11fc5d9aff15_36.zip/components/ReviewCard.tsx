
'use client';

import Link from 'next/link';

interface ReviewCardProps {
  title: string;
  excerpt: string;
  rating: number;
  category: string;
  imageUrl: string;
  date: string;
  author: string;
}

export default function ReviewCard({ title, excerpt, rating, category, imageUrl, date, author }: ReviewCardProps) {
  // Generate URL slug from title
  const generateSlug = (title: string) => {
    return title.toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  };

  const getReviewUrl = (title: string) => {
    const slug = generateSlug(title);
    
    // Map specific titles to existing pages
    if (title.includes('Solar Power Bank')) {
      return '/reviews/solar-power-bank';
    } else if (title.includes('Bamboo Wireless Charging')) {
      return '/reviews/bamboo-wireless-charger';
    } else if (title.includes('Smart Thermostat')) {
      return '/reviews/smart-thermostat';
    }
    
    // Default fallback for other reviews
    return `/reviews/${slug}`;
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-emerald-100 overflow-hidden hover:shadow-md transition-shadow">
      <div className="aspect-w-16 aspect-h-9">
        <img 
          src={imageUrl} 
          alt={title}
          className="w-full h-48 object-cover object-top"
        />
      </div>
      
      <div className="p-6">
        <div className="flex items-center justify-between mb-3">
          <span className="bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full text-sm font-medium">
            {category}
          </span>
          <div className="flex items-center space-x-1">
            {[...Array(5)].map((_, i) => (
              <i 
                key={i} 
                className={`${i < rating ? 'ri-star-fill text-yellow-400' : 'ri-star-line text-gray-300'} text-sm`}
              ></i>
            ))}
          </div>
        </div>
        
        <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">
          {title}
        </h3>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-3">
          {excerpt}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="text-xs text-gray-500">
            <span>{date}</span> • <span>{author}</span>
          </div>
          <Link 
            href={getReviewUrl(title)}
            className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer"
          >
            Read More →
          </Link>
        </div>
      </div>
    </div>
  );
}

'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import NewsletterSignup from '@/components/NewsletterSignup';
import Link from 'next/link';

export default function DIYSolarPhoneChargerPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="relative bg-gradient-to-r from-emerald-50 to-teal-50 py-20">
          <div 
            className="absolute inset-0 bg-cover bg-center opacity-10"
            style={{
              backgroundImage: `url('https://readdy.ai/api/search-image?query=DIY%20solar%20phone%20charger%20project%20workspace%20with%20solar%20panels%2C%20electronic%20components%2C%20tools%2C%20sustainable%20energy%20project%2C%20green%20technology%20building&width=1200&height=600&seq=diy-solar-hero-1&orientation=landscape')`
            }}
          ></div>
          <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <div className="inline-flex items-center space-x-2 bg-emerald-100 text-emerald-600 px-4 py-2 rounded-full text-sm font-medium mb-4">
                <i className="ri-tools-line"></i>
                <span>DIY Projects</span>
              </div>
              <h1 className="text-5xl font-bold text-gray-900 mb-6">
                Build Your Own Solar Phone Charger
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Create a portable solar charging station for your devices using affordable components. 
                Perfect for camping, emergencies, or reducing grid dependency.
              </p>
              <div className="flex items-center justify-center space-x-6 text-sm text-gray-500">
                <span className="flex items-center space-x-1">
                  <i className="ri-time-line"></i>
                  <span>8 min read</span>
                </span>
                <span className="flex items-center space-x-1">
                  <i className="ri-user-line"></i>
                  <span>EcoTechPicks Team</span>
                </span>
                <span className="flex items-center space-x-1">
                  <i className="ri-calendar-line"></i>
                  <span>Updated Dec 2024</span>
                </span>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="prose prose-lg max-w-none">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-6 mb-8">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-amber-600 rounded-full flex items-center justify-center">
                    <i className="ri-lightbulb-line text-white text-sm"></i>
                  </div>
                  <div>
                    <h3 className="text-amber-800 font-semibold mb-1">Project Overview</h3>
                    <p className="text-amber-700 text-sm">
                      Difficulty: Beginner • Time: 2-3 hours • Cost: $30-50 • Skills: Basic soldering
                    </p>
                  </div>
                </div>
              </div>

              <h2 className="text-2xl font-bold text-gray-900 mb-4">Materials Needed</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-900 mb-3">Electronic Components</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>5W Solar Panel (6V output)</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>USB Boost Converter (5V output)</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>18650 Battery (3.7V, 3000mAh)</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>Battery Holder</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>Diode (1N4007)</span>
                    </li>
                  </ul>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-900 mb-3">Tools & Housing</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>Plastic Project Box</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>Soldering Iron & Solder</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>Wire Strippers</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>Drill with Bits</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <i className="ri-checkbox-circle-line text-emerald-600"></i>
                      <span>USB Female Connector</span>
                    </li>
                  </ul>
                </div>
              </div>

              <h2 className="text-2xl font-bold text-gray-900 mb-4">Step-by-Step Instructions</h2>
              
              <div className="space-y-8">
                <div className="border-l-4 border-emerald-600 pl-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Step 1: Prepare the Enclosure</h3>
                  <p className="text-gray-700 mb-4">
                    Drill holes in your project box for the USB connector and any indicator LEDs. Make sure the solar panel 
                    can be mounted on top or connected via wire. Test fit all components before proceeding.
                  </p>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <p className="text-blue-700 text-sm">
                      <strong>Safety Tip:</strong> Always wear safety glasses when drilling and ensure proper ventilation.
                    </p>
                  </div>
                </div>

                <div className="border-l-4 border-emerald-600 pl-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Step 2: Wire the Solar Panel</h3>
                  <p className="text-gray-700 mb-4">
                    Connect the solar panel's positive terminal to the anode of the diode. This prevents reverse current 
                    flow at night. Connect the diode's cathode to the positive terminal of the battery holder.
                  </p>
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                    <p className="text-amber-700 text-sm">
                      <strong>Important:</strong> The diode stripe indicates the cathode (negative) side.
                    </p>
                  </div>
                </div>

                <div className="border-l-4 border-emerald-600 pl-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Step 3: Install the Boost Converter</h3>
                  <p className="text-gray-700 mb-4">
                    Connect the boost converter's input to the battery terminals. The converter will step up the 3.7V 
                    battery voltage to 5V USB standard. Connect the USB connector to the converter's output.
                  </p>
                </div>

                <div className="border-l-4 border-emerald-600 pl-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Step 4: Test and Assemble</h3>
                  <p className="text-gray-700 mb-4">
                    Before final assembly, test all connections with a multimeter. Insert the charged battery and verify 
                    5V output at the USB port. Secure all components in the enclosure and close the box.
                  </p>
                </div>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 mt-8">
                <h3 className="text-emerald-800 font-semibold mb-2">Expected Performance</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="text-center">
                    <div className="font-semibold text-emerald-700">Charging Time</div>
                    <div className="text-emerald-600">6-8 hours full sun</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-emerald-700">Phone Charges</div>
                    <div className="text-emerald-600">1-2 full charges</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-emerald-700">Battery Life</div>
                    <div className="text-emerald-600">500+ cycles</div>
                  </div>
                </div>
              </div>

              <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-12">Troubleshooting Tips</h2>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center">
                    <i className="ri-close-line text-red-600 text-sm"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">No charging output</h4>
                    <p className="text-gray-700 text-sm">Check all solder connections and verify diode orientation.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center">
                    <i className="ri-close-line text-red-600 text-sm"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Slow charging</h4>
                    <p className="text-gray-700 text-sm">Ensure solar panel is getting direct sunlight and clean the surface.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center">
                    <i className="ri-close-line text-red-600 text-sm"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Battery not holding charge</h4>
                    <p className="text-gray-700 text-sm">Battery may be old or damaged. Replace with a new 18650 cell.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-6">
                  Ready for Your Next DIY Project?
                </h2>
                <p className="text-gray-600 mb-8">
                  Join our community of makers and builders. Share your projects, get inspiration, 
                  and discover new ways to create sustainable technology solutions.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link href="/tips" className="bg-emerald-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer text-center">
                    More DIY Tips
                  </Link>
                  <Link href="/submit-tip" className="border border-emerald-600 text-emerald-600 px-6 py-3 rounded-lg font-semibold hover:bg-emerald-50 transition-colors whitespace-nowrap cursor-pointer text-center">
                    Share Your Project
                  </Link>
                </div>
              </div>
              <div>
                <NewsletterSignup />
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
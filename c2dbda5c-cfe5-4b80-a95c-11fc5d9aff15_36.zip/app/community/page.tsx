
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { useState } from 'react';

export default function CommunityPage() {
  const [showJoinMessage, setShowJoinMessage] = useState(false);
  const [showSocialMessage, setShowSocialMessage] = useState(false);

  const handleJoinDiscord = () => {
    setShowJoinMessage(true);
    setTimeout(() => setShowJoinMessage(false), 3000);
  };

  const handleFollowSocial = () => {
    setShowSocialMessage(true);
    setTimeout(() => setShowSocialMessage(false), 3000);
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Success Messages */}
      {showJoinMessage && (
        <div className="fixed top-4 right-4 bg-emerald-600 text-white px-6 py-3 rounded-lg shadow-lg z-50">
          <div className="flex items-center">
            <i className="ri-check-line text-xl mr-2"></i>
            Discord invite sent! Check your notifications.
          </div>
        </div>
      )}

      {showSocialMessage && (
        <div className="fixed top-4 right-4 bg-emerald-600 text-white px-6 py-3 rounded-lg shadow-lg z-50">
          <div className="flex items-center">
            <i className="ri-check-line text-xl mr-2"></i>
            Following on social media! Thanks for connecting.
          </div>
        </div>
      )}

      <main>
        <section className="relative bg-gradient-to-r from-emerald-50 to-teal-50 py-20">
          <div
            className="absolute inset-0 bg-cover bg-center opacity-10"
            style={{
              backgroundImage: `url('https://readdy.ai/api/search-image?query=diverse%20community%20of%20people%20sharing%20eco-friendly%20technology%20ideas%2C%20green%20living%20workshop%2C%20sustainable%20lifestyle%20community%2C%20environmental%20activists%20with%20solar%20panels%20and%20plants&width=1200&height=600&seq=community-hero-1&orientation=landscape')`
            }}
          ></div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-5xl font-bold text-gray-900 mb-6">
                Join Our Green Tech
                <span className="text-emerald-600"> Community</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                Connect with thousands of eco-conscious individuals who are passionate about sustainable technology
                and making a positive impact on our planet.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={handleJoinDiscord}
                  className="bg-emerald-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer"
                >
                  Join Discord
                </button>
                <Link
                  href="/discord-guide"
                  className="border border-emerald-600 text-emerald-600 px-8 py-4 rounded-lg font-semibold hover:bg-emerald-50 transition-colors whitespace-nowrap cursor-pointer"
                >
                  New to Discord? Learn Here
                </Link>
                <button
                  onClick={handleFollowSocial}
                  className="border border-emerald-600 text-emerald-600 px-8 py-4 rounded-lg font-semibold hover:bg-emerald-50 transition-colors whitespace-nowrap cursor-pointer"
                >
                  Follow on Social
                </button>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Community Features
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Everything you need to connect, learn, and share your green tech journey.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6">
                <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mb-4">
                  <i className="ri-message-3-line text-white text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Discussion Forums
                </h3>
                <p className="text-gray-600">
                  Share experiences, ask questions, and get advice from fellow green tech enthusiasts.
                </p>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6">
                <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mb-4">
                  <i className="ri-lightbulb-line text-white text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Project Sharing
                </h3>
                <p className="text-gray-600">
                  Showcase your DIY green tech projects and inspire others with your innovations.
                </p>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6">
                <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mb-4">
                  <i className="ri-calendar-event-line text-white text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Virtual Events
                </h3>
                <p className="text-gray-600">
                  Join webinars, workshops, and virtual meetups with industry experts and community members.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Community Stats
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="text-4xl font-bold text-emerald-600 mb-2">15,000+</div>
                <div className="text-gray-600">Active Members</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-emerald-600 mb-2">2,500+</div>
                <div className="text-gray-600">Projects Shared</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-emerald-600 mb-2">850+</div>
                <div className="text-gray-600">Discussion Topics</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-emerald-600 mb-2">120+</div>
                <div className="text-gray-600">Events Hosted</div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-emerald-600">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-white mb-4">
              Ready to Make a Difference?
            </h2>
            <p className="text-emerald-100 text-lg mb-8 max-w-2xl mx-auto">
              Join our community today and start connecting with like-minded individuals who share your passion for sustainable technology.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/register"
                className="bg-white text-emerald-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-50 transition-colors whitespace-nowrap cursor-pointer"
              >
                Create Account
              </Link>
              <Link
                href="/discord-guide"
                className="border border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer"
              >
                Discord Guide
              </Link>
              <Link href="/tips" className="border border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer">
                Explore Tips
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

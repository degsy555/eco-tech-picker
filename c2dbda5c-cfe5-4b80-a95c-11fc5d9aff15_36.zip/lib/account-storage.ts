
export interface AccountData {
  fullName: string;
  email: string;
  interests: string[];
  newsletter: boolean;
  createdAt: string;
  id: string;
}

export function saveAccountToStorage(accountData: Omit<AccountData, 'createdAt' | 'id'>): AccountData {
  try {
    const existingAccounts = getAccountsFromStorage();
    
    // Check if email already exists
    const emailExists = existingAccounts.some(account => account.email.toLowerCase() === accountData.email.toLowerCase());
    
    if (emailExists) {
      throw new Error('An account with this email already exists');
    }

    const newAccount: AccountData = {
      ...accountData,
      createdAt: new Date().toISOString(),
      id: Date.now().toString()
    };

    const updatedAccounts = [...existingAccounts, newAccount];
    localStorage.setItem('ecotechpicks-accounts', JSON.stringify(updatedAccounts));
    
    return newAccount;
  } catch (error) {
    console.error('Error saving account:', error);
    throw error;
  }
}

export function getAccountsFromStorage(): AccountData[] {
  try {
    const accounts = localStorage.getItem('ecotechpicks-accounts');
    return accounts ? JSON.parse(accounts) : [];
  } catch (error) {
    console.error('Error retrieving accounts:', error);
    return [];
  }
}

export function getAccountByEmail(email: string): AccountData | null {
  try {
    const accounts = getAccountsFromStorage();
    return accounts.find(account => account.email.toLowerCase() === email.toLowerCase()) || null;
  } catch (error) {
    console.error('Error finding account:', error);
    return null;
  }
}

export function updateAccount(id: string, updates: Partial<AccountData>): AccountData | null {
  try {
    const accounts = getAccountsFromStorage();
    const accountIndex = accounts.findIndex(account => account.id === id);
    
    if (accountIndex === -1) {
      return null;
    }

    const updatedAccount = { ...accounts[accountIndex], ...updates };
    accounts[accountIndex] = updatedAccount;
    
    localStorage.setItem('ecotechpicks-accounts', JSON.stringify(accounts));
    return updatedAccount;
  } catch (error) {
    console.error('Error updating account:', error);
    return null;
  }
}

export function deleteAccount(id: string): boolean {
  try {
    const accounts = getAccountsFromStorage();
    const filteredAccounts = accounts.filter(account => account.id !== id);
    
    localStorage.setItem('ecotechpicks-accounts', JSON.stringify(filteredAccounts));
    return true;
  } catch (error) {
    console.error('Error deleting account:', error);
    return false;
  }
}

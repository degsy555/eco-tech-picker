'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function SmartHomeEnergyMonitoringPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="py-16 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <Link href="/tips" className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                ← Back to Tips
              </Link>
            </div>
            
            <article>
              <header className="mb-8">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
                    <i className="ri-home-wifi-line text-white text-xl"></i>
                  </div>
                  <span className="bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full text-sm font-medium">
                    Smart Home
                  </span>
                </div>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                  Create a Smart Home Energy Monitoring System
                </h1>
                <div className="flex items-center space-x-4 text-gray-600">
                  <span className="flex items-center space-x-1">
                    <i className="ri-time-line"></i>
                    <span>4 min read</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <i className="ri-calendar-line"></i>
                    <span>Updated March 2024</span>
                  </span>
                </div>
              </header>
              
              <div className="prose prose-lg max-w-none">
                <img 
                  src="https://readdy.ai/api/search-image?query=smart%20home%20energy%20monitoring%20system%20with%20smartphone%20app%20showing%20energy%20usage%20data%2C%20modern%20home%20interior%20with%20smart%20devices%2C%20energy%20efficiency%20dashboard%2C%20connected%20home%20technology&width=800&height=400&seq=smart-monitoring-1&orientation=landscape"
                  alt="Smart home energy monitoring"
                  className="rounded-lg shadow-lg mb-8 w-full h-96 object-cover object-top"
                />
                
                <p className="text-xl text-gray-600 mb-8">
                  Transform your home into an energy-efficient smart home with real-time monitoring. Track your consumption, identify energy vampires, and optimize your usage patterns for maximum savings.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Essential Smart Monitoring Devices</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">1. Smart Plugs</h3>
                <p className="text-gray-600 mb-4">
                  Start with smart plugs that monitor individual device consumption. They're affordable and provide instant insights into which appliances are using the most energy.
                </p>
                
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 mb-6">
                  <h4 className="text-lg font-semibold text-emerald-800 mb-3">Recommended Smart Plugs:</h4>
                  <ul className="text-emerald-700 space-y-2">
                    <li>• TP-Link Kasa Smart Plug (Energy Monitoring)</li>
                    <li>• Amazon Smart Plug (works with Alexa)</li>
                    <li>• Emporia Vue Smart Plug</li>
                  </ul>
                </div>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">2. Whole-Home Energy Monitors</h3>
                <p className="text-gray-600 mb-6">
                  For comprehensive monitoring, install a whole-home energy monitor. These devices connect to your electrical panel and track your entire home's energy usage.
                </p>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">3. Smart Thermostats</h3>
                <p className="text-gray-600 mb-6">
                  Smart thermostats not only control temperature but also monitor HVAC energy usage, which typically accounts for 40-50% of your energy bill.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Setting Up Your Monitoring System</h2>
                
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-blue-800 mb-3">Step-by-Step Setup:</h3>
                  <ol className="text-blue-700 space-y-2">
                    <li>1. Install smart plugs on high-usage devices (refrigerator, washer, TV)</li>
                    <li>2. Set up a whole-home monitor at your electrical panel</li>
                    <li>3. Connect devices to your home Wi-Fi network</li>
                    <li>4. Download manufacturer apps and create accounts</li>
                    <li>5. Configure alerts for unusual energy usage</li>
                  </ol>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Identifying Energy Vampires</h2>
                
                <p className="text-gray-600 mb-6">
                  Energy vampires are devices that continue to draw power even when turned off. Common culprits include:
                </p>
                
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• Cable boxes and DVRs</li>
                  <li>• Gaming consoles</li>
                  <li>• Coffee makers with digital displays</li>
                  <li>• Chargers left plugged in</li>
                  <li>• Printers and scanners</li>
                </ul>
                
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-yellow-800 mb-3">Pro Tip:</h3>
                  <p className="text-yellow-700">
                    Use smart plugs to automatically cut power to devices during off-hours. This can reduce standby power consumption by up to 10% of your total energy usage.
                  </p>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Optimizing Your Energy Usage</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Time-of-Use Strategies</h3>
                <p className="text-gray-600 mb-4">
                  Many utility companies offer time-of-use rates. Use your monitoring data to shift energy-intensive tasks to off-peak hours:
                </p>
                
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• Run dishwashers and washing machines at night</li>
                  <li>• Charge electric vehicles during off-peak hours</li>
                  <li>• Use smart thermostats to pre-cool/heat during cheaper rate periods</li>
                </ul>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Automated Energy Savings</h3>
                <p className="text-gray-600 mb-6">
                  Set up automated rules to optimize energy usage without manual intervention:
                </p>
                
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 mb-8">
                  <h4 className="text-lg font-semibold text-emerald-800 mb-3">Automation Ideas:</h4>
                  <ul className="text-emerald-700 space-y-2">
                    <li>• Turn off entertainment systems when no one's home</li>
                    <li>• Adjust thermostat based on occupancy</li>
                    <li>• Limit high-energy device usage during peak hours</li>
                    <li>• Send alerts when daily energy usage exceeds targets</li>
                  </ul>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Tracking Your Progress</h2>
                
                <p className="text-gray-600 mb-6">
                  Most smart energy devices come with mobile apps that provide detailed analytics. Look for:
                </p>
                
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• Daily, weekly, and monthly usage trends</li>
                  <li>• Device-by-device breakdowns</li>
                  <li>• Cost projections based on current usage</li>
                  <li>• Comparison with similar homes in your area</li>
                </ul>
                
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-800 mb-3">Expected Savings:</h3>
                  <p className="text-gray-700 mb-4">
                    Most homes see 10-15% energy savings within the first year of implementing smart monitoring. The investment typically pays for itself within 12-18 months.
                  </p>
                  <Link href="/tips" className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                    → Explore More Smart Home Tips
                  </Link>
                </div>
              </div>
            </article>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
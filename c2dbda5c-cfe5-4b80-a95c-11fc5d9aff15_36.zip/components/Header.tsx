'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b border-emerald-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-2 cursor-pointer">
              <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center">
                <i className="ri-leaf-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-gray-900 font-pacifico">EcoTechPicks</span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
              Home
            </Link>
            <Link href="/reviews" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
              Reviews
            </Link>
            <Link href="/tips" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
              Tips
            </Link>
            <Link href="/community" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
              Community
            </Link>
            <Link href="/submit-tip" className="bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors cursor-pointer whitespace-nowrap">
              Submit Tip
            </Link>
          </nav>

          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-emerald-600 cursor-pointer"
            >
              <i className={`ri-${isMenuOpen ? 'close' : 'menu'}-line text-xl`}></i>
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden border-t border-emerald-100 py-4">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                Home
              </Link>
              <Link href="/reviews" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                Reviews
              </Link>
              <Link href="/tips" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                Tips
              </Link>
              <Link href="/community" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                Community
              </Link>
              <Link href="/submit-tip" className="bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors cursor-pointer whitespace-nowrap w-fit">
                Submit Tip
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
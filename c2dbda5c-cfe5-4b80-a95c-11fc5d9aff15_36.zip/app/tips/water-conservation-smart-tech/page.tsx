'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function WaterConservationSmartTechPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="py-16 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <Link href="/tips" className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                ← Back to Tips
              </Link>
            </div>
            
            <article>
              <header className="mb-8">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
                    <i className="ri-drop-line text-white text-xl"></i>
                  </div>
                  <span className="bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full text-sm font-medium">
                    Water Saving
                  </span>
                </div>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                  Water Conservation with Smart Technology
                </h1>
                <div className="flex items-center space-x-4 text-gray-600">
                  <span className="flex items-center space-x-1">
                    <i className="ri-time-line"></i>
                    <span>4 min read</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <i className="ri-calendar-line"></i>
                    <span>Updated March 2024</span>
                  </span>
                </div>
              </header>
              
              <div className="prose prose-lg max-w-none">
                <img 
                  src="https://readdy.ai/api/search-image?query=smart%20water%20irrigation%20system%20in%20garden%20with%20sensors%20monitoring%20soil%20moisture%2C%20smartphone%20app%20controlling%20water%20usage%2C%20green%20plants%20and%20lawn%2C%20water%20conservation%20technology%2C%20sustainable%20landscaping&width=800&height=400&seq=water-smart-1&orientation=landscape"
                  alt="Smart water conservation system"
                  className="rounded-lg shadow-lg mb-8 w-full h-96 object-cover object-top"
                />
                
                <p className="text-xl text-gray-600 mb-8">
                  Smart water technology can reduce your water usage by up to 30% while maintaining beautiful landscapes and comfortable homes. Discover how intelligent systems can help you conserve this precious resource.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">The Water Crisis Challenge</h2>
                
                <p className="text-gray-600 mb-6">
                  With water scarcity affecting 40% of the global population, every drop counts. Smart technology offers innovative solutions to help homeowners reduce consumption without sacrificing comfort or aesthetics.
                </p>
                
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-blue-800 mb-3">Water Usage Breakdown:</h3>
                  <ul className="text-blue-700 space-y-2">
                    <li>• <strong>Outdoor irrigation:</strong> 30% of household water use</li>
                    <li>• <strong>Toilets:</strong> 24% of indoor water consumption</li>
                    <li>• <strong>Washing machines:</strong> 20% of indoor usage</li>
                    <li>• <strong>Showers:</strong> 17% of indoor water use</li>
                    <li>• <strong>Faucets:</strong> 19% of indoor consumption</li>
                  </ul>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Smart Irrigation Systems</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Weather-Based Controllers</h3>
                <p className="text-gray-600 mb-4">
                  These systems adjust watering schedules based on real-time weather data:
                </p>
                
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• Skip watering during rain or high humidity</li>
                  <li>• Adjust for temperature and evapotranspiration rates</li>
                  <li>• Seasonal adjustments for plant needs</li>
                  <li>• Remote control via smartphone apps</li>
                </ul>
                
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-emerald-800 mb-3">Popular Smart Irrigation Brands:</h3>
                  <ul className="text-emerald-700 space-y-2">
                    <li>• <strong>Rachio:</strong> Weather intelligence, zone control</li>
                    <li>• <strong>Rain Bird:</strong> Professional-grade systems</li>
                    <li>• <strong>Orbit B-hyve:</strong> Affordable smart timers</li>
                    <li>• <strong>Netro:</strong> AI-powered watering optimization</li>
                    <li>• <strong>Hunter:</strong> Robust commercial-grade options</li>
                  </ul>
                </div>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Soil Moisture Sensors</h3>
                <p className="text-gray-600 mb-6">
                  Install sensors that measure actual soil moisture levels to prevent overwatering and ensure plants get exactly what they need.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Indoor Water Conservation Tech</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Smart Leak Detection</h3>
                <p className="text-gray-600 mb-4">
                  Prevent water waste and damage with intelligent leak detection systems:
                </p>
                
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• <strong>Flo by Moen:</strong> Whole-home water monitoring</li>
                  <li>• <strong>Phyn Plus:</strong> AI-powered leak detection</li>
                  <li>• <strong>Sense:</strong> Smart water sensor with app alerts</li>
                  <li>• <strong>Water Hero:</strong> Automatic shut-off capabilities</li>
                </ul>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Smart Showerheads and Faucets</h3>
                <p className="text-gray-600 mb-4">
                  Modern fixtures offer precise flow control and usage tracking:
                </p>
                
                <ul className="text-gray-600 mb-8 space-y-2">
                  <li>• Temperature presets to reduce warm-up waste</li>
                  <li>• Flow rate monitoring and alerts</li>
                  <li>• Automatic shut-off after preset time</li>
                  <li>• Usage tracking and reporting</li>
                </ul>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Greywater Recycling Systems</h2>
                
                <p className="text-gray-600 mb-6">
                  Reuse water from showers, sinks, and washing machines for irrigation:
                </p>
                
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-yellow-800 mb-3">Greywater Benefits:</h3>
                  <ul className="text-yellow-700 space-y-2">
                    <li>• Reduces freshwater demand by 30-50%</li>
                    <li>• Nutrients in greywater benefit plants</li>
                    <li>• Reduces strain on septic systems</li>
                    <li>• Can be automated with smart pumps</li>
                  </ul>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Rainwater Harvesting Technology</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Smart Collection Systems</h3>
                <p className="text-gray-600 mb-4">
                  Modern rainwater harvesting includes intelligent features:
                </p>
                
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• Automatic first-flush diverters</li>
                  <li>• Level monitoring with app notifications</li>
                  <li>• Automated distribution to irrigation zones</li>
                  <li>• Water quality testing sensors</li>
                </ul>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Calculate Your Potential</h3>
                <p className="text-gray-600 mb-8">
                  A 1,000 square foot roof can collect about 600 gallons from 1 inch of rainfall. Smart systems maximize this potential by optimizing collection timing and storage.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Smart Water Monitoring and Analytics</h2>
                
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-emerald-800 mb-3">Key Metrics to Track:</h3>
                  <ul className="text-emerald-700 space-y-2">
                    <li>• Daily water consumption patterns</li>
                    <li>• Cost per gallon and monthly spending</li>
                    <li>• Irrigation efficiency rates</li>
                    <li>• Leak detection and prevention</li>
                    <li>• Conservation goal progress</li>
                  </ul>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Installation and Setup Tips</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">DIY vs Professional Installation</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                    <h4 className="text-lg font-semibold text-blue-800 mb-3">DIY Friendly:</h4>
                    <ul className="text-blue-700 space-y-2">
                      <li>• Smart irrigation controllers</li>
                      <li>• Leak detection sensors</li>
                      <li>• Smart showerheads</li>
                      <li>• Basic rainwater barrels</li>
                    </ul>
                  </div>
                  
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                    <h4 className="text-lg font-semibold text-yellow-800 mb-3">Professional Required:</h4>
                    <ul className="text-yellow-700 space-y-2">
                      <li>• Whole-home water monitoring</li>
                      <li>• Greywater recycling systems</li>
                      <li>• Complex irrigation installations</li>
                      <li>• Plumbing modifications</li>
                    </ul>
                  </div>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Cost-Benefit Analysis</h2>
                
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-emerald-800 mb-3">Investment Examples:</h3>
                  <div className="text-emerald-700 space-y-3">
                    <div>
                      <div className="font-medium">Smart Irrigation Controller: $150-300</div>
                      <div className="text-sm">Annual savings: $200-400</div>
                    </div>
                    <div>
                      <div className="font-medium">Leak Detection System: $300-800</div>
                      <div className="text-sm">Prevents thousands in damage costs</div>
                    </div>
                    <div>
                      <div className="font-medium">Rainwater Harvesting: $1,000-3,000</div>
                      <div className="text-sm">Long-term water independence</div>
                    </div>
                  </div>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Getting Started</h2>
                
                <p className="text-gray-600 mb-6">
                  Begin your water conservation journey with these simple steps:
                </p>
                
                <ol className="text-gray-600 mb-8 space-y-2">
                  <li>1. Audit your current water usage patterns</li>
                  <li>2. Start with a smart irrigation controller</li>
                  <li>3. Install leak detection sensors in key areas</li>
                  <li>4. Gradually add more sophisticated systems</li>
                  <li>5. Monitor and adjust based on results</li>
                </ol>
                
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-800 mb-3">Expected Results:</h3>
                  <p className="text-gray-700 mb-4">
                    Smart water conservation systems typically reduce consumption by 20-30% while maintaining or improving landscape health. Most systems pay for themselves within 2-3 years through reduced water bills.
                  </p>
                  <Link href="/tips" className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                    → Explore More Water Conservation Tips
                  </Link>
                </div>
              </div>
            </article>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}

'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { useState } from 'react';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    'first-name': '',
    'last-name': '',
    email: '',
    subject: '',
    message: '',
    'newsletter-signup': false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState('');
  const [messageCount, setMessageCount] = useState(0);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;

    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    if (name === 'message') {
      setMessageCount(value.length);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (formData.message.length > 500) {
      setError('Message must be 500 characters or less.');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const response = await fetch('https://readdy.ai/api/form-submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          formId: 'contact-form',
          ...formData,
          'newsletter-signup': formData['newsletter-signup'] ? 'true' : 'false'
        }),
      });

      if (response.ok) {
        setIsSubmitted(true);
        setFormData({
          'first-name': '',
          'last-name': '',
          email: '',
          subject: '',
          message: '',
          'newsletter-signup': false
        });
        setMessageCount(0);
      } else {
        setError('Something went wrong. Please try again.');
      }
    } catch (error) {
      console.error('Submission error:', error);
      setError('Network error. Please check your connection and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setIsSubmitted(false);
    setError('');
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <main>
        <section className="relative bg-gradient-to-r from-emerald-50 to-teal-50 py-20">
          <div
            className="absolute inset-0 bg-cover bg-center opacity-10"
            style={{
              backgroundImage: `url('https://readdy.ai/api/search-image?query=modern%20eco-friendly%20office%20contact%20center%20with%20green%20plants%2C%20sustainable%20workspace%2C%20customer%20service%20team%2C%20environmental%20technology%20background%2C%20bright%20natural%20lighting&width=1200&height=600&seq=contact-hero-1&orientation=landscape')`
            }}
          ></div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-5xl font-bold text-gray-900 mb-6">
                Get in
                <span className="text-emerald-600">Touch</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                Have questions about eco-friendly tech? Want to collaborate? Or simply want to share your thoughts?
                We'd love to hear from you.
              </p>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-8">
                  Send Us a Message
                </h2>

                {isSubmitted ? (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-8 text-center">
                    <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-check-line text-white text-2xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-emerald-800 mb-2">
                      Message Sent Successfully!
                    </h3>
                    <p className="text-emerald-600 mb-4">
                      Thank you for contacting us. We'll get back to you within 24 hours.
                    </p>
                    <button
                      onClick={resetForm}
                      className="text-emerald-600 hover:text-emerald-700 font-semibold cursor-pointer"
                    >
                      Send Another Message
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <fieldset disabled={isSubmitting}>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label htmlFor="first-name" className="block text-sm font-medium text-gray-700 mb-2">
                            First Name *
                          </label>
                          <input
                            type="text"
                            id="first-name"
                            name="first-name"
                            value={formData['first-name']}
                            onChange={handleInputChange}
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                            placeholder="Your first name"
                          />
                        </div>
                        <div>
                          <label htmlFor="last-name" className="block text-sm font-medium text-gray-700 mb-2">
                            Last Name *
                          </label>
                          <input
                            type="text"
                            id="last-name"
                            name="last-name"
                            value={formData['last-name']}
                            onChange={handleInputChange}
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                            placeholder="Your last name"
                          />
                        </div>
                      </div>

                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                          placeholder="your.email@example.com"
                        />
                      </div>

                      <div>
                        <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">
                          Subject *
                        </label>
                        <select
                          id="subject"
                          name="subject"
                          value={formData.subject}
                          onChange={handleInputChange}
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm pr-8"
                        >
                          <option value="">Select a subject</option>
                          <option value="general-inquiry">General Inquiry</option>
                          <option value="product-review">Product Review Request</option>
                          <option value="collaboration">Collaboration Opportunity</option>
                          <option value="press-media">Press & Media</option>
                          <option value="technical-support">Technical Support</option>
                          <option value="feedback">Feedback & Suggestions</option>
                        </select>
                      </div>

                      <div>
                        <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                          Message *
                        </label>
                        <textarea
                          id="message"
                          name="message"
                          rows={6}
                          value={formData.message}
                          onChange={handleInputChange}
                          required
                          maxLength={500}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                          placeholder="Tell us how we can help you..."
                        ></textarea>
                        <div className="text-right text-sm text-gray-500 mt-1">
                          <span className={messageCount > 500 ? 'text-red-500' : ''}>{messageCount}</span>/500 characters
                        </div>
                      </div>

                      <div className="flex items-start space-x-3">
                        <input
                          type="checkbox"
                          id="newsletter-signup"
                          name="newsletter-signup"
                          checked={formData['newsletter-signup']}
                          onChange={handleInputChange}
                          className="w-4 h-4 text-emerald-600 border-gray-300 rounded focus:ring-emerald-500"
                        />
                        <label htmlFor="newsletter-signup" className="text-sm text-gray-700">
                          I'd like to receive updates about new reviews and green tech tips
                        </label>
                      </div>

                      {error && (
                        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                          <div className="flex items-center">
                            <i className="ri-error-warning-line text-red-600 mr-2"></i>
                            <p className="text-red-600 text-sm">{error}</p>
                          </div>
                        </div>
                      )}
                    </fieldset>

                    <button
                      type="submit"
                      disabled={isSubmitting || formData.message.length > 500}
                      className="w-full bg-emerald-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap cursor-pointer"
                    >
                      {isSubmitting ? (
                        <span className="flex items-center justify-center space-x-2">
                          <i className="ri-loader-4-line animate-spin"></i>
                          <span>Sending...</span>
                        </span>
                      ) : (
                        'Send Message'
                      )}
                    </button>
                  </form>
                )}
              </div>

              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-8">
                  Other Ways to Connect
                </h2>

                <div className="space-y-6">
                  <div className="bg-gray-50 rounded-lg p-6">
                    <div className="flex items-center space-x-4 mb-4">
                      <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
                        <i className="ri-mail-line text-white text-xl"></i>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">
                          Email Us Directly
                        </h3>
                        <p className="text-gray-600">
                          hello@ecotechpicks.com
                        </p>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600">
                      We typically respond within 24 hours during business days.
                    </p>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-6">
                    <div className="flex items-center space-x-4 mb-4">
                      <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
                        <i className="ri-twitter-line text-white text-xl"></i>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">
                          Follow Us on Social
                        </h3>
                        <p className="text-gray-600">
                          @EcoTechPicks
                        </p>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600">
                      Get daily updates and interact with our community.
                    </p>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-6">
                    <div className="flex items-center space-x-4 mb-4">
                      <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
                        <i className="ri-map-pin-line text-white text-xl"></i>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">
                          Visit Our Office
                        </h3>
                        <p className="text-gray-600">
                          123 Green Tech Lane<br />
                          Eco City, CA 90210
                        </p>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600">
                      By appointment only. Please contact us first.
                    </p>
                  </div>

                  <div className="mt-8">
                    <h3 className="text-xl font-semibold text-gray-900 mb-4">
                      Quick Links
                    </h3>
                    <div className="space-y-3">
                      <Link href="/tips" className="block text-emerald-600 hover:text-emerald-700 cursor-pointer">
                        → Browse Green Living Tips
                      </Link>
                      <Link href="/reviews" className="block text-emerald-600 hover:text-emerald-700 cursor-pointer">
                        → Read Latest Reviews
                      </Link>
                      <Link href="/submit-tip" className="block text-emerald-600 hover:text-emerald-700 cursor-pointer">
                        → Submit Your Own Tip
                      </Link>
                      <Link href="/community" className="block text-emerald-600 hover:text-emerald-700 cursor-pointer">
                        → Join Our Community
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Frequently Asked Questions
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Find answers to common questions about our reviews, recommendations, and services.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  How do you test products?
                </h3>
                <p className="text-gray-600 text-sm">
                  We conduct thorough testing over several weeks, evaluating performance,
                  energy efficiency, durability, and environmental impact before writing our reviews.
                </p>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  Do you accept product submissions?
                </h3>
                <p className="text-gray-600 text-sm">
                  Yes! We welcome product submissions from manufacturers. Please contact us
                  with detailed information about your eco-friendly technology product.
                </p>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  Are your reviews sponsored?
                </h3>
                <p className="text-gray-600 text-sm">
                  Our reviews are completely independent and unbiased. We clearly disclose
                  any sponsored content, but our opinions are always our own.
                </p>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  How can I contribute content?
                </h3>
                <p className="text-gray-600 text-sm">
                  We love community contributions! You can submit tips, share your experiences,
                  or even write guest posts. Contact us to learn more about our contributor program.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

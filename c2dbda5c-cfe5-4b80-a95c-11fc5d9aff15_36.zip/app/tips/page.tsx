
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import NewsletterSignup from '@/components/NewsletterSignup';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { getApprovedTips, type SubmittedTip } from '@/lib/tips-storage';

export default function TipsPage() {
  const [submittedTips, setSubmittedTips] = useState<SubmittedTip[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      const tips = getApprovedTips();
      setSubmittedTips(tips);
    } catch (error) {
      console.log('Error loading tips:', error);
      setSubmittedTips([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const defaultTips = [
    {
      title: "Switch to LED Bulbs for Instant Energy Savings",
      content: "Replace all incandescent bulbs with LED alternatives to reduce energy consumption by up to 80%. LED bulbs last 25 times longer and produce less heat, making them perfect for eco-conscious homes.",
      category: "Energy Saving",
      icon: "ri-lightbulb-line",
      readTime: "2 min read",
      slug: "switch-to-led-bulbs",
      author: "EcoTechPicks Team"
    },
    {
      title: "Create a Smart Home Energy Monitoring System",
      content: "Install smart plugs and energy monitors to track your device usage in real-time. This helps identify energy vampires and optimize your consumption patterns for maximum savings.",
      category: "Smart Home",
      icon: "ri-home-wifi-line",
      readTime: "4 min read",
      slug: "smart-home-energy-monitoring",
      author: "EcoTechPicks Team"
    },
    {
      title: "Solar Panel Maintenance for Maximum Efficiency",
      content: "Keep your solar panels clean and debris-free to maintain peak performance. Regular cleaning can improve efficiency by up to 15%. Check for shading issues and ensure proper ventilation.",
      category: "Solar Energy",
      icon: "ri-sun-line",
      readTime: "3 min read",
      slug: "solar-panel-maintenance",
      author: "EcoTechPicks Team"
    },
    {
      title: "Sustainable Tech Disposal and Recycling",
      content: "Properly dispose of old electronics through certified e-waste recycling programs. Many manufacturers offer take-back programs for their products. Never throw electronics in regular trash.",
      category: "Recycling",
      icon: "ri-recycle-line",
      readTime: "5 min read",
      slug: "sustainable-tech-disposal",
      author: "EcoTechPicks Team"
    },
    {
      title: "Building an Eco-Friendly Home Office",
      content: "Use energy-efficient equipment, natural lighting, and sustainable materials. Position your desk near windows to reduce artificial lighting needs and invest in plants for natural air purification.",
      category: "Workspace",
      icon: "ri-plant-line",
      readTime: "6 min read",
      slug: "eco-friendly-home-office",
      author: "EcoTechPicks Team"
    },
    {
      title: "Water Conservation with Smart Technology",
      content: "Install smart irrigation systems and water leak detectors to prevent waste. Smart sprinklers can reduce water usage by up to 20% by adjusting based on weather conditions and soil moisture.",
      category: "Water Saving",
      icon: "ri-drop-line",
      readTime: "4 min read",
      slug: "water-conservation-smart-tech",
      author: "EcoTechPicks Team"
    },
    {
      title: "Build Your Own Solar Phone Charger",
      content: "Create a portable solar charging station for your devices using affordable components. Perfect for camping, emergencies, or reducing grid dependency with this beginner-friendly project.",
      category: "DIY Projects",
      icon: "ri-tools-line",
      readTime: "8 min read",
      slug: "diy-solar-phone-charger",
      author: "EcoTechPicks Team"
    },
    {
      title: "DIY Smart Plant Monitor",
      content: "Build an automated plant monitoring system that tracks soil moisture, light levels, and temperature. Keep your plants healthy with real-time data and alerts for optimal growing conditions.",
      category: "DIY Projects",
      icon: "ri-tools-line",
      readTime: "12 min read",
      slug: "diy-smart-plant-monitor",
      author: "EcoTechPicks Team"
    }
  ];

  const categoryIcons: { [key: string]: string } = {
    'energy-saving': 'ri-lightbulb-line',
    'smart-home': 'ri-home-wifi-line',
    'solar-energy': 'ri-sun-line',
    'recycling': 'ri-recycle-line',
    'water-saving': 'ri-drop-line',
    'diy-projects': 'ri-tools-line',
    'sustainable-materials': 'ri-leaf-line',
    'digital-habits': 'ri-smartphone-line'
  };

  const getCategoryDisplayName = (category: string) => {
    const categoryMap: { [key: string]: string } = {
      'energy-saving': 'Energy Saving',
      'smart-home': 'Smart Home',
      'solar-energy': 'Solar Energy',
      'recycling': 'Recycling',
      'water-saving': 'Water Saving',
      'diy-projects': 'DIY Projects',
      'sustainable-materials': 'Sustainable Materials',
      'digital-habits': 'Digital Habits'
    };
    return categoryMap[category] || category;
  };

  const userTips = submittedTips.map(tip => ({
    title: tip.title,
    content: tip.content,
    category: getCategoryDisplayName(tip.category),
    icon: categoryIcons[tip.category] || 'ri-lightbulb-line',
    readTime: "3 min read",
    slug: null,
    author: tip.author,
    isUserSubmitted: true
  }));

  const allTips = [...defaultTips, ...userTips];

  const filteredTips = selectedCategory === 'all' 
    ? allTips 
    : allTips.filter(tip => tip.category.toLowerCase().replace(' ', '-') === selectedCategory);

  const categories = [
    { id: 'all', name: 'All Tips' },
    { id: 'energy-saving', name: 'Energy Saving' },
    { id: 'smart-home', name: 'Smart Home' },
    { id: 'solar-energy', name: 'Solar Energy' },
    { id: 'water-saving', name: 'Water Saving' },
    { id: 'recycling', name: 'Recycling' },
    { id: 'diy-projects', name: 'DIY Projects' }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <main className="flex items-center justify-center py-20">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Loading tips...</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="relative bg-gradient-to-r from-emerald-50 to-teal-50 py-20">
          <div 
            className="absolute inset-0 bg-cover bg-center opacity-10"
            style={{
              backgroundImage: `url('https://readdy.ai/api/search-image?query=green%20sustainable%20living%20tips%20background%20with%20eco-friendly%20lifestyle%20elements%2C%20solar%20panels%2C%20plants%2C%20recycling%20symbols%2C%20energy%20efficient%20home%2C%20environmental%20conservation%20theme&width=1200&height=600&seq=tips-hero-1&orientation=landscape')`
            }}
          ></div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-5xl font-bold text-gray-900 mb-6">
                Green Living 
                <span className="text-emerald-600"> Tips & Guides</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                Practical advice for sustainable living with technology. Learn how to reduce your environmental impact 
                while embracing innovative eco-friendly solutions.
              </p>
              <div className="flex flex-wrap justify-center gap-4 mb-8">
                {categories.map(category => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`px-6 py-2 rounded-full font-medium transition-colors whitespace-nowrap cursor-pointer ${
                      selectedCategory === category.id
                        ? 'bg-emerald-600 text-white'
                        : 'border border-emerald-600 text-emerald-600 hover:bg-emerald-50'
                    }`}
                  >
                    {category.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {filteredTips.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredTips.map((tip, index) => (
                  <div key={index} className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6 hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
                        <i className={`${tip.icon} text-white text-xl`}></i>
                      </div>
                      <div className="text-right">
                        <span className="bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full text-sm font-medium">
                          {tip.category}
                        </span>
                      </div>
                    </div>
                    
                    <h3 className="text-xl font-semibold text-gray-900 mb-3">
                      {tip.title}
                    </h3>
                    
                    <p className="text-gray-600 mb-4 line-clamp-3">
                      {tip.content}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex flex-col space-y-1">
                        <span className="text-sm text-gray-500 flex items-center space-x-1">
                          <i className="ri-time-line"></i>
                          <span>{tip.readTime}</span>
                        </span>
                        <span className="text-xs text-gray-400">
                          by {tip.author}
                        </span>
                      </div>
                      {tip.slug && (
                        <Link href={`/tips/${tip.slug}`} className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                          Read More →
                        </Link>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-search-line text-gray-400 text-2xl"></i>
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No tips found</h3>
                <p className="text-gray-600">
                  No tips match the selected category. Try selecting a different category or submit your own tip!
                </p>
              </div>
            )}
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-6">
                  Take Action Today for a Greener Tomorrow
                </h2>
                <p className="text-gray-600 mb-8">
                  Every small step counts when it comes to sustainable living. Start with one tip today 
                  and gradually build habits that benefit both your wallet and the environment.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center">
                      <i className="ri-check-line text-white text-sm"></i>
                    </div>
                    <span className="text-gray-700">Start with simple energy-saving switches</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center">
                      <i className="ri-check-line text-white text-sm"></i>
                    </div>
                    <span className="text-gray-700">Monitor your progress with smart technology</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center">
                      <i className="ri-check-line text-white text-sm"></i>
                    </div>
                    <span className="text-gray-700">Share your success with our community</span>
                  </div>
                </div>
              </div>
              
              <div>
                <NewsletterSignup />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-emerald-600">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-white mb-4">
              Have a Green Tech Tip to Share?
            </h2>
            <p className="text-emerald-100 text-lg mb-8 max-w-2xl mx-auto">
              We'd love to hear about your eco-friendly discoveries and sustainable living hacks. 
              Join our community of green tech enthusiasts.
            </p>
            <Link href="/submit-tip" className="bg-white text-emerald-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-50 transition-colors whitespace-nowrap cursor-pointer">
              Submit Your Tip
            </Link>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}

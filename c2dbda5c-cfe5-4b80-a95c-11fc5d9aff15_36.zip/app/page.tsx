
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ReviewCard from '@/components/ReviewCard';
import NewsletterSignup from '@/components/NewsletterSignup';
import Link from 'next/link';

export default function Home() {
  const featuredReviews = [
    {
      title: "Solar Power Bank 20000mAh - Endless Energy for Your Adventures",
      excerpt: "This solar power bank delivers reliable renewable energy for all your devices. Perfect for camping, hiking, and emergency situations. Features fast charging and weather-resistant design.",
      rating: 5,
      category: "Solar Energy",
      imageUrl: "https://readdy.ai/api/search-image?query=modern%20solar%20power%20bank%20portable%20charger%20lying%20on%20wooden%20table%20with%20green%20plants%20in%20background%2C%20clean%20white%20background%2C%20eco-friendly%20technology%2C%20professional%20product%20photography&width=400&height=250&seq=solar-powerbank-1&orientation=landscape",
      date: "March 15, 2024",
      author: "Sarah Green"
    },
    {
      title: "Bamboo Wireless Charging Pad - Sustainable Tech That Actually Works",
      excerpt: "Made from 100% sustainable bamboo, this wireless charger combines eco-consciousness with cutting-edge technology. Fast charging capabilities with zero plastic waste.",
      rating: 4,
      category: "Sustainable Materials",
      imageUrl: "https://readdy.ai/api/search-image?query=bamboo%20wireless%20charging%20pad%20with%20smartphone%20on%20top%2C%20wooden%20desk%20setting%20with%20small%20green%20plants%2C%20minimalist%20eco-friendly%20design%2C%20warm%20natural%20lighting&width=400&height=250&seq=bamboo-charger-1&orientation=landscape",
      date: "March 12, 2024",
      author: "Mike Chen"
    },
    {
      title: "Energy-Efficient Smart Thermostat - Save Money While Saving the Planet",
      excerpt: "This AI-powered thermostat learns your habits and optimizes energy usage automatically. Reduced our energy bill by 30% while maintaining perfect comfort levels.",
      rating: 5,
      category: "Energy Efficient",
      imageUrl: "https://readdy.ai/api/search-image?query=modern%20smart%20thermostat%20mounted%20on%20white%20wall%20with%20green%20living%20room%20background%2C%20digital%20display%20showing%20temperature%2C%20eco-friendly%20home%20technology%2C%20clean%20minimal%20design&width=400&height=250&seq=smart-thermostat-1&orientation=landscape",
      date: "March 10, 2024",
      author: "Emma Wilson"
    },
    {
      title: "Recycled Plastic Bluetooth Speaker - Great Sound, Greater Impact",
      excerpt: "Built entirely from ocean plastic waste, this speaker delivers premium audio quality while helping clean our oceans. Waterproof design perfect for outdoor adventures.",
      rating: 4,
      category: "Sustainable Materials",
      imageUrl: "https://readdy.ai/api/search-image?query=bluetooth%20speaker%20made%20from%20recycled%20plastic%20sitting%20on%20beach%20sand%20with%20ocean%20waves%20in%20background%2C%20eco-friendly%20design%2C%20sustainable%20technology%2C%20blue%20and%20green%20color%20scheme&width=400&height=250&seq=recycled-speaker-1&orientation=landscape",
      date: "March 8, 2024",
      author: "David Park"
    },
    {
      title: "LED Desk Lamp with Solar Panel - Bright Ideas for Green Workspaces",
      excerpt: "This innovative desk lamp features built-in solar panels that charge during the day and provide brilliant LED lighting for evening work. Adjustable brightness and color temperature.",
      rating: 4,
      category: "Solar Energy",
      imageUrl: "https://readdy.ai/api/search-image?query=modern%20LED%20desk%20lamp%20with%20solar%20panel%20on%20top%2C%20sitting%20on%20wooden%20desk%20with%20laptop%20and%20plants%2C%20home%20office%20setting%2C%20bright%20natural%20lighting%2C%20eco-friendly%20workspace&width=400&height=250&seq=solar-desk-lamp-1&orientation=landscape",
      date: "March 5, 2024",
      author: "Lisa Johnson"
    },
    {
      title: "Kinetic Energy Smartwatch - Powered by Your Movement",
      excerpt: "Never charge your smartwatch again! This revolutionary device generates power from your daily movements. Full fitness tracking, notifications, and weeks of battery life.",
      rating: 5,
      category: "Energy Efficient",
      imageUrl: "https://readdy.ai/api/search-image?query=sleek%20black%20smartwatch%20on%20wrist%20showing%20fitness%20data%2C%20person%20jogging%20in%20green%20park%20background%2C%20kinetic%20energy%20technology%2C%20active%20lifestyle%2C%20modern%20wearable%20device&width=400&height=250&seq=kinetic-watch-1&orientation=landscape",
      date: "March 3, 2024",
      author: "Alex Turner"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="relative bg-gradient-to-r from-emerald-50 to-teal-50 py-20">
          <div 
            className="absolute inset-0 bg-cover bg-center opacity-10"
            style={{
              backgroundImage: `url('https://readdy.ai/api/search-image?query=sustainable%20technology%20background%20with%20green%20plants%20and%20eco-friendly%20gadgets%2C%20solar%20panels%2C%20wind%20turbines%2C%20clean%20energy%20devices%2C%20bright%20natural%20lighting%2C%20environmental%20conservation%20theme&width=1200&height=600&seq=hero-bg-1&orientation=landscape')`
            }}
          ></div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-5xl font-bold text-gray-900 mb-6">
                Discover Eco-Friendly Tech That 
                <span className="text-emerald-600"> Changes Everything</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                In-depth reviews of sustainable gadgets, green technology, and eco-conscious products 
                that help you live better while protecting our planet.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/tips" className="bg-emerald-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer">
                  Explore Green Tips
                </Link>
                <Link href="/reviews" className="border border-emerald-600 text-emerald-600 px-8 py-4 rounded-lg font-semibold hover:bg-emerald-50 transition-colors whitespace-nowrap cursor-pointer">
                  Latest Reviews
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Latest Eco-Tech Reviews
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Discover the most innovative sustainable technology products, 
                tested and reviewed by our team of environmental tech experts.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredReviews.map((review, index) => (
                <ReviewCard key={index} {...review} />
              ))}
            </div>
            
            <div className="text-center mt-12">
              <Link href="/reviews" className="bg-emerald-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer">
                View All Reviews
              </Link>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <h2 className="text-3xl font-bold text-gray-900 mb-8">
                  Why Choose Eco-Friendly Tech?
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white rounded-lg p-6 shadow-sm border border-emerald-100">
                    <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mb-4">
                      <i className="ri-leaf-line text-white text-xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      Environmental Impact
                    </h3>
                    <p className="text-gray-600">
                      Reduce your carbon footprint with technology that's designed to protect our planet.
                    </p>
                  </div>
                  <div className="bg-white rounded-lg p-6 shadow-sm border border-emerald-100">
                    <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mb-4">
                      <i className="ri-money-dollar-circle-line text-white text-xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      Cost Savings
                    </h3>
                    <p className="text-gray-600">
                      Save money on energy bills while investing in sustainable technology solutions.
                    </p>
                  </div>
                  <div className="bg-white rounded-lg p-6 shadow-sm border border-emerald-100">
                    <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mb-4">
                      <i className="ri-shield-check-line text-white text-xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      Future-Proof
                    </h3>
                    <p className="text-gray-600">
                      Invest in technology that's built to last and adapt to changing environmental needs.
                    </p>
                  </div>
                  <div className="bg-white rounded-lg p-6 shadow-sm border border-emerald-100">
                    <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mb-4">
                      <i className="ri-heart-line text-white text-xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      Health Benefits
                    </h3>
                    <p className="text-gray-600">
                      Enjoy cleaner air and healthier living environments with eco-conscious products.
                    </p>
                  </div>
                </div>
              </div>
              
              <div>
                <NewsletterSignup />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-emerald-600">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-white mb-4">
              Join the Green Tech Revolution
            </h2>
            <p className="text-emerald-100 text-lg mb-8 max-w-2xl mx-auto">
              Be part of a community that's passionate about sustainable technology and making a positive impact on our planet.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/tips" className="bg-white text-emerald-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-50 transition-colors whitespace-nowrap cursor-pointer">
                Get Green Tips
              </Link>
              <Link href="/community" className="border border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer">
                Join Community
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

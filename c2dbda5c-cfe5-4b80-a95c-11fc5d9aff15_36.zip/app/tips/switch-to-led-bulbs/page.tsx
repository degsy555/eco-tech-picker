'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function SwitchToLEDBulbsPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="py-16 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <Link href="/tips" className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                ← Back to Tips
              </Link>
            </div>
            
            <article>
              <header className="mb-8">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
                    <i className="ri-lightbulb-line text-white text-xl"></i>
                  </div>
                  <span className="bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full text-sm font-medium">
                    Energy Saving
                  </span>
                </div>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                  Switch to LED Bulbs for Instant Energy Savings
                </h1>
                <div className="flex items-center space-x-4 text-gray-600">
                  <span className="flex items-center space-x-1">
                    <i className="ri-time-line"></i>
                    <span>2 min read</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <i className="ri-calendar-line"></i>
                    <span>Updated March 2024</span>
                  </span>
                </div>
              </header>
              
              <div className="prose prose-lg max-w-none">
                <img 
                  src="https://readdy.ai/api/search-image?query=LED%20light%20bulbs%20comparison%20with%20incandescent%20bulbs%20on%20wooden%20table%2C%20energy%20efficient%20lighting%2C%20bright%20white%20background%2C%20eco-friendly%20home%20improvement%2C%20sustainable%20lighting%20solution&width=800&height=400&seq=led-bulbs-1&orientation=landscape"
                  alt="LED bulbs comparison"
                  className="rounded-lg shadow-lg mb-8 w-full h-96 object-cover object-top"
                />
                
                <p className="text-xl text-gray-600 mb-8">
                  Making the switch to LED bulbs is one of the easiest and most effective ways to reduce your home's energy consumption. Here's everything you need to know about this simple but powerful upgrade.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Why LED Bulbs Are a Game-Changer</h2>
                
                <p className="text-gray-600 mb-6">
                  LED (Light Emitting Diode) bulbs use up to 80% less energy than traditional incandescent bulbs while lasting 25 times longer. This means significant savings on both your electricity bill and replacement costs.
                </p>
                
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-emerald-800 mb-3">Quick Comparison:</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <div className="font-medium text-emerald-700">Incandescent Bulb</div>
                      <div className="text-emerald-600">60W, 1,000 hours</div>
                    </div>
                    <div>
                      <div className="font-medium text-emerald-700">CFL Bulb</div>
                      <div className="text-emerald-600">14W, 8,000 hours</div>
                    </div>
                    <div>
                      <div className="font-medium text-emerald-700">LED Bulb</div>
                      <div className="text-emerald-600">9W, 25,000 hours</div>
                    </div>
                  </div>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">How to Choose the Right LED Bulbs</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">1. Check the Brightness (Lumens)</h3>
                <p className="text-gray-600 mb-4">
                  Don't focus on wattage – look for lumens instead. A 60W incandescent bulb produces about 800 lumens, which you can get from a 9W LED bulb.
                </p>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">2. Consider Color Temperature</h3>
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• <strong>2700K-3000K:</strong> Warm white (similar to incandescent)</li>
                  <li>• <strong>3500K-4100K:</strong> Cool white (good for kitchens)</li>
                  <li>• <strong>5000K-6500K:</strong> Daylight (ideal for workspaces)</li>
                </ul>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">3. Check for ENERGY STAR Certification</h3>
                <p className="text-gray-600 mb-6">
                  ENERGY STAR certified LEDs have been tested for performance and efficiency. They're guaranteed to produce the promised light output and last for years.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Installation Tips</h2>
                
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-yellow-800 mb-3">Safety First!</h3>
                  <p className="text-yellow-700">
                    Always turn off power at the switch before replacing bulbs. Wait for old bulbs to cool down if they've been on recently.
                  </p>
                </div>
                
                <ol className="text-gray-600 mb-8 space-y-3">
                  <li><strong>1.</strong> Start with the most-used rooms first to maximize immediate savings</li>
                  <li><strong>2.</strong> Replace bulbs in fixtures that are on for more than 3 hours daily</li>
                  <li><strong>3.</strong> Consider dimmable LEDs for living areas and bedrooms</li>
                  <li><strong>4.</strong> Don't forget outdoor lighting – LED bulbs work great in all weather</li>
                </ol>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Calculate Your Savings</h2>
                
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-emerald-800 mb-3">Example Calculation:</h3>
                  <div className="text-emerald-700 space-y-2">
                    <div>Replacing 10 bulbs used 5 hours daily:</div>
                    <div>• Annual electricity savings: $75-100</div>
                    <div>• LED bulb cost: $50-70</div>
                    <div>• Payback period: 8-10 months</div>
                    <div>• Total 10-year savings: $800-1,000</div>
                  </div>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Common Mistakes to Avoid</h2>
                
                <ul className="text-gray-600 mb-8 space-y-3">
                  <li>• Don't use LEDs in enclosed fixtures unless they're specifically rated for it</li>
                  <li>• Avoid cheap, non-certified bulbs that may flicker or fail prematurely</li>
                  <li>• Don't assume all LEDs are dimmable – check the packaging</li>
                  <li>• Don't mix different color temperatures in the same room</li>
                </ul>
                
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-800 mb-3">Next Steps:</h3>
                  <p className="text-gray-700 mb-4">
                    Ready to make the switch? Start by replacing your five most-used bulbs and experience the difference immediately. Your wallet and the environment will thank you!
                  </p>
                  <Link href="/tips" className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                    → Explore More Green Tips
                  </Link>
                </div>
              </div>
            </article>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
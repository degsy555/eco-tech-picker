'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function SustainableTechDisposalPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="py-16 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <Link href="/tips" className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                ← Back to Tips
              </Link>
            </div>
            
            <article>
              <header className="mb-8">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
                    <i className="ri-recycle-line text-white text-xl"></i>
                  </div>
                  <span className="bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full text-sm font-medium">
                    Recycling
                  </span>
                </div>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                  Sustainable Tech Disposal and Recycling
                </h1>
                <div className="flex items-center space-x-4 text-gray-600">
                  <span className="flex items-center space-x-1">
                    <i className="ri-time-line"></i>
                    <span>5 min read</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <i className="ri-calendar-line"></i>
                    <span>Updated March 2024</span>
                  </span>
                </div>
              </header>
              
              <div className="prose prose-lg max-w-none">
                <img 
                  src="https://readdy.ai/api/search-image?query=electronic%20waste%20recycling%20center%20with%20smartphones%2C%20laptops%2C%20tablets%20being%20properly%20disposed%20of%2C%20green%20recycling%20process%2C%20sustainable%20technology%20disposal%2C%20environmental%20conservation&width=800&height=400&seq=tech-disposal-1&orientation=landscape"
                  alt="Electronic waste recycling"
                  className="rounded-lg shadow-lg mb-8 w-full h-96 object-cover object-top"
                />
                
                <p className="text-xl text-gray-600 mb-8">
                  Electronic waste is one of the fastest-growing waste streams globally. Learning how to properly dispose of old tech devices isn't just environmentally responsible—it's essential for protecting our planet's future.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Why Proper E-Waste Disposal Matters</h2>
                
                <p className="text-gray-600 mb-6">
                  Electronic devices contain both valuable materials and hazardous substances. When improperly disposed of, these toxins can leach into soil and groundwater, causing environmental damage and health risks.
                </p>
                
                <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-red-800 mb-3">Toxic Materials in Electronics:</h3>
                  <ul className="text-red-700 space-y-2">
                    <li>• Lead (in screens and circuit boards)</li>
                    <li>• Mercury (in switches and flat screens)</li>
                    <li>• Cadmium (in batteries and semiconductors)</li>
                    <li>• Brominated flame retardants (in plastic casings)</li>
                    <li>• Chromium (in metal housings)</li>
                  </ul>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Before You Dispose: Data Security</h2>
                
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-yellow-800 mb-3">Essential Security Steps:</h3>
                  <ol className="text-yellow-700 space-y-2">
                    <li>1. Back up important data to cloud or external storage</li>
                    <li>2. Sign out of all accounts and remove authorization</li>
                    <li>3. Perform factory reset on all devices</li>
                    <li>4. Remove or destroy hard drives from computers</li>
                    <li>5. Remove SIM cards and memory cards</li>
                  </ol>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Disposal Options by Device Type</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Smartphones and Tablets</h3>
                <ul className="text-gray-600 mb-4 space-y-2">
                  <li>• Manufacturer take-back programs (Apple, Samsung, Google)</li>
                  <li>• Carrier trade-in programs (Verizon, AT&T, T-Mobile)</li>
                  <li>• Retailer recycling (Best Buy, Amazon, Staples)</li>
                  <li>• Certified e-waste recyclers</li>
                </ul>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Laptops and Computers</h3>
                <ul className="text-gray-600 mb-4 space-y-2">
                  <li>• Manufacturer recycling programs (Dell, HP, Lenovo)</li>
                  <li>• Local electronics stores</li>
                  <li>• Municipal e-waste collection events</li>
                  <li>• Refurbishment programs for working devices</li>
                </ul>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Batteries</h3>
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• Battery drop-off locations (Home Depot, Lowe's)</li>
                  <li>• Call2Recycle program locations</li>
                  <li>• Electronics stores with battery recycling</li>
                  <li>• Never put batteries in regular trash</li>
                </ul>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Manufacturer Take-Back Programs</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-emerald-800 mb-3">Apple</h3>
                    <ul className="text-emerald-700 space-y-2">
                      <li>• Apple Trade In program</li>
                      <li>• Free recycling at Apple Stores</li>
                      <li>• Mail-in options available</li>
                      <li>• Accepts any brand of device</li>
                    </ul>
                  </div>
                  
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-blue-800 mb-3">Samsung</h3>
                    <ul className="text-blue-700 space-y-2">
                      <li>• Samsung Galaxy Upcycling program</li>
                      <li>• Trade-in discounts for new devices</li>
                      <li>• Certified recycling partners</li>
                      <li>• Eco-packaging initiatives</li>
                    </ul>
                  </div>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Certified E-Waste Recyclers</h2>
                
                <p className="text-gray-600 mb-6">
                  When choosing a recycling service, look for certifications that ensure responsible processing:
                </p>
                
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-emerald-800 mb-3">Look for These Certifications:</h3>
                  <ul className="text-emerald-700 space-y-2">
                    <li>• <strong>R2 (Responsible Recycling):</strong> Ensures proper data destruction and environmental handling</li>
                    <li>• <strong>e-Stewards:</strong> Prohibits export of toxic e-waste to developing countries</li>
                    <li>• <strong>ISO 14001:</strong> Environmental management system certification</li>
                    <li>• <strong>NAID AAA:</strong> Data destruction certification</li>
                  </ul>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">DIY Refurbishment and Donation</h2>
                
                <p className="text-gray-600 mb-6">
                  Before recycling, consider if your device can be refurbished or donated:
                </p>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Donation Options</h3>
                <ul className="text-gray-600 mb-6 space-y-2">
                  <li>• Schools and educational programs</li>
                  <li>• Senior centers and community organizations</li>
                  <li>• Goodwill and Salvation Army</li>
                  <li>• World Computer Exchange</li>
                  <li>• National Cristina Foundation</li>
                </ul>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Refurbishment Tips</h3>
                <ul className="text-gray-600 mb-8 space-y-2">
                  <li>• Clean and test all functions</li>
                  <li>• Update software to latest version</li>
                  <li>• Replace batteries if needed</li>
                  <li>• Include original accessories if available</li>
                  <li>• Verify device is unlocked (for phones)</li>
                </ul>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Planning for Future Disposal</h2>
                
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-semibold text-blue-800 mb-3">Best Practices for New Purchases:</h3>
                  <ul className="text-blue-700 space-y-2">
                    <li>• Choose devices with longer lifespans</li>
                    <li>• Buy from companies with robust take-back programs</li>
                    <li>• Consider modular designs for easier repair</li>
                    <li>• Keep original packaging for future recycling</li>
                    <li>• Research disposal options before purchasing</li>
                  </ul>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Finding Local E-Waste Events</h2>
                
                <p className="text-gray-600 mb-6">
                  Many communities host periodic e-waste collection events. Find local events through:
                </p>
                
                <ul className="text-gray-600 mb-8 space-y-2">
                  <li>• Municipal waste management websites</li>
                  <li>• Earth911.com recycling locator</li>
                  <li>• Local environmental organizations</li>
                  <li>• Community Facebook groups</li>
                  <li>• Library and community center bulletin boards</li>
                </ul>
                
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-800 mb-3">Make a Difference:</h3>
                  <p className="text-gray-700 mb-4">
                    By properly disposing of just one smartphone, you can recover enough materials to make 25 new smartphones. Every device recycled makes a real environmental impact.
                  </p>
                  <Link href="/tips" className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                    → Explore More Sustainability Tips
                  </Link>
                </div>
              </div>
            </article>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
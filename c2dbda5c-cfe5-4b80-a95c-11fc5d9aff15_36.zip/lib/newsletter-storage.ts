
interface NewsletterSubscription {
  id: string;
  email: string;
  subscribedAt: string;
  isActive: boolean;
}

const STORAGE_KEY = 'eco-newsletter-subscriptions';

export function saveSubscription(email: string): void {
  const subscriptions = getSubscriptions();
  
  // Check if email already exists
  const existingSubscription = subscriptions.find(sub => sub.email === email);
  if (existingSubscription) {
    // Reactivate if previously unsubscribed
    existingSubscription.isActive = true;
    existingSubscription.subscribedAt = new Date().toISOString();
  } else {
    // Add new subscription
    const newSubscription: NewsletterSubscription = {
      id: Date.now().toString(),
      email,
      subscribedAt: new Date().toISOString(),
      isActive: true
    };
    subscriptions.push(newSubscription);
  }
  
  localStorage.setItem(STORAGE_KEY, JSON.stringify(subscriptions));
}

export function getSubscriptions(): NewsletterSubscription[] {
  if (typeof window === 'undefined') return [];
  
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) return [];
  
  try {
    return JSON.parse(stored);
  } catch (error) {
    console.error('Error parsing newsletter subscriptions:', error);
    return [];
  }
}

export function getActiveSubscriptions(): NewsletterSubscription[] {
  return getSubscriptions().filter(sub => sub.isActive);
}

export function unsubscribeEmail(email: string): void {
  const subscriptions = getSubscriptions();
  const subscription = subscriptions.find(sub => sub.email === email);
  
  if (subscription) {
    subscription.isActive = false;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(subscriptions));
  }
}

export function getSubscriptionStats() {
  const subscriptions = getSubscriptions();
  const activeCount = subscriptions.filter(sub => sub.isActive).length;
  const totalCount = subscriptions.length;
  
  return {
    activeSubscriptions: activeCount,
    totalSubscriptions: totalCount,
    recentSubscriptions: subscriptions
      .filter(sub => sub.isActive)
      .sort((a, b) => new Date(b.subscribedAt).getTime() - new Date(a.subscribedAt).getTime())
      .slice(0, 10)
  };
}

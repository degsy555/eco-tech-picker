'use client';

export interface SubmittedTip {
  id: string;
  title: string;
  category: string;
  content: string;
  author: string;
  email: string;
  website?: string;
  submittedAt: string;
  status: 'pending' | 'approved' | 'rejected';
}

export const getTipsFromStorage = (): SubmittedTip[] => {
  if (typeof window === 'undefined') return [];
  
  try {
    const stored = localStorage.getItem('submitted-tips');
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

export const saveTipToStorage = (tip: Omit<SubmittedTip, 'id' | 'submittedAt' | 'status'>): SubmittedTip => {
  const newTip: SubmittedTip = {
    ...tip,
    id: Date.now().toString(),
    submittedAt: new Date().toISOString(),
    status: 'pending'
  };

  const existingTips = getTipsFromStorage();
  const updatedTips = [...existingTips, newTip];
  
  localStorage.setItem('submitted-tips', JSON.stringify(updatedTips));
  
  return newTip;
};

export const getApprovedTips = (): SubmittedTip[] => {
  return getTipsFromStorage().filter(tip => tip.status === 'approved');
};

export const approveTip = (id: string): void => {
  const tips = getTipsFromStorage();
  const updatedTips = tips.map(tip => 
    tip.id === id ? { ...tip, status: 'approved' as const } : tip
  );
  localStorage.setItem('submitted-tips', JSON.stringify(updatedTips));
};

export const rejectTip = (id: string): void => {
  const tips = getTipsFromStorage();
  const updatedTips = tips.map(tip => 
    tip.id === id ? { ...tip, status: 'rejected' as const } : tip
  );
  localStorage.setItem('submitted-tips', JSON.stringify(updatedTips));
};

export const generateSlug = (title: string): string => {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
};
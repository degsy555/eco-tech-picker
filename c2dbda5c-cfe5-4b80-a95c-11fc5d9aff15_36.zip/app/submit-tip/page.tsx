
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { useState } from 'react';
import { saveTipToStorage } from '@/lib/tips-storage';

export default function SubmitTipPage() {
  const [formData, setFormData] = useState({
    'tip-title': '',
    'tip-category': '',
    'tip-description': '',
    'your-name': '',
    'your-email': '',
    'website-url': '',
    'terms-agreement': false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState('');
  const [descriptionCount, setDescriptionCount] = useState(0);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;

    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    if (name === 'tip-description') {
      setDescriptionCount(value.length);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (formData['tip-description'].length > 500) {
      setError('Description must be 500 characters or less.');
      return;
    }

    if (!formData['terms-agreement']) {
      setError('Please agree to the terms before submitting.');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      // Save tip to local storage
      const savedTip = saveTipToStorage({
        title: formData['tip-title'],
        category: formData['tip-category'],
        content: formData['tip-description'],
        author: formData['your-name'],
        email: formData['your-email'],
        website: formData['website-url'] || undefined
      });

      // Also submit to the API endpoint for backup/additional processing
      const submitData = new URLSearchParams();
      submitData.append('formId', 'tip-submission-form');
      submitData.append('tip-title', formData['tip-title']);
      submitData.append('tip-category', formData['tip-category']);
      submitData.append('tip-description', formData['tip-description']);
      submitData.append('your-name', formData['your-name']);
      submitData.append('your-email', formData['your-email']);
      submitData.append('website-url', formData['website-url']);
      submitData.append('terms-agreement', formData['terms-agreement'] ? 'true' : 'false');

      // Continue with API submission but don't let it block the UI
      fetch('https://readdy.ai/api/form-submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: submitData.toString(),
      }).catch(() => {
        // Silently handle API errors since we're storing locally
      });

      setIsSubmitted(true);
      setFormData({
        'tip-title': '',
        'tip-category': '',
        'tip-description': '',
        'your-name': '',
        'your-email': '',
        'website-url': '',
        'terms-agreement': false
      });
      setDescriptionCount(0);

      // Scroll to top to show success message
      window.scrollTo({ top: 0, behavior: 'smooth' });

    } catch (error) {
      console.error('Submission error:', error);
      setError('Unable to submit tip. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setIsSubmitted(false);
    setError('');
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <main>
        <section className="relative bg-gradient-to-r from-emerald-50 to-teal-50 py-20">
          <div 
            className="absolute inset-0 bg-cover bg-center opacity-10"
            style={{
              backgroundImage: `url('https://readdy.ai/api/search-image?query=person%20writing%20green%20technology%20tips%20on%20laptop%20with%20eco-friendly%20workspace%2C%20sustainable%20living%20ideas%2C%20environmental%20conservation%20notes%2C%20modern%20home%20office%20with%20plants&width=1200&height=600&seq=submit-hero-1&orientation=landscape')`
            }}
          ></div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-5xl font-bold text-gray-900 mb-6">
                Share Your Green Tech
                <span className="text-emerald-600"> Tips</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                Help our community grow by sharing your eco-friendly discoveries, sustainable living hacks, 
                and innovative green technology solutions.
              </p>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            {isSubmitted ? (
              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-8 text-center">
                <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-check-line text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-emerald-800 mb-2">
                  Tip Submitted Successfully!
                </h3>
                <p className="text-emerald-600 mb-6">
                  Thank you for sharing your green tech tip! We'll review it and email you within 24 hours.
                </p>
                <div className="space-y-4">
                  <button
                    onClick={resetForm}
                    className="bg-emerald-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer"
                  >
                    Submit Another Tip
                  </button>
                  <div>
                    <Link href="/tips" className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                      View All Tips →
                    </Link>
                  </div>
                </div>
              </div>
            ) : (
              <form id="tip-submission-form" onSubmit={handleSubmit} className="bg-white rounded-lg shadow-sm border border-emerald-100 p-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Submit Your Tip</h2>

                <fieldset disabled={isSubmitting} className="space-y-6">
                  <div>
                    <label htmlFor="tip-title" className="block text-sm font-medium text-gray-700 mb-2">
                      Tip Title *
                    </label>
                    <input
                      type="text"
                      id="tip-title"
                      name="tip-title"
                      value={formData['tip-title']}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                      placeholder="Enter a descriptive title for your tip"
                    />
                  </div>

                  <div>
                    <label htmlFor="tip-category" className="block text-sm font-medium text-gray-700 mb-2">
                      Category *
                    </label>
                    <select
                      id="tip-category"
                      name="tip-category"
                      value={formData['tip-category']}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm pr-8"
                    >
                      <option value="">Select a category</option>
                      <option value="energy-saving">Energy Saving</option>
                      <option value="smart-home">Smart Home</option>
                      <option value="solar-energy">Solar Energy</option>
                      <option value="recycling">Recycling</option>
                      <option value="water-saving">Water Saving</option>
                      <option value="diy-projects">DIY Projects</option>
                      <option value="sustainable-materials">Sustainable Materials</option>
                      <option value="digital-habits">Digital Habits</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="tip-description" className="block text-sm font-medium text-gray-700 mb-2">
                      Tip Description *
                    </label>
                    <textarea
                      id="tip-description"
                      name="tip-description"
                      rows={6}
                      value={formData['tip-description']}
                      onChange={handleInputChange}
                      required
                      maxLength={500}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                      placeholder="Describe your tip in detail. What makes it effective? How does it help the environment?"
                    ></textarea>
                    <div className="text-right text-sm text-gray-500 mt-1">
                      <span className={descriptionCount > 500 ? 'text-red-500' : ''}>{descriptionCount}</span>/500 characters
                    </div>
                  </div>

                  <div>
                    <label htmlFor="your-name" className="block text-sm font-medium text-gray-700 mb-2">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      id="your-name"
                      name="your-name"
                      value={formData['your-name']}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                      placeholder="How should we credit you?"
                    />
                  </div>

                  <div>
                    <label htmlFor="your-email" className="block text-sm font-medium text-gray-700 mb-2">
                      Your Email *
                    </label>
                    <input
                      type="email"
                      id="your-email"
                      name="your-email"
                      value={formData['your-email']}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                      placeholder="We'll contact you if we feature your tip"
                    />
                  </div>

                  <div>
                    <label htmlFor="website-url" className="block text-sm font-medium text-gray-700 mb-2">
                      Website/Social Media (Optional)
                    </label>
                    <input
                      type="url"
                      id="website-url"
                      name="website-url"
                      value={formData['website-url']}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                      placeholder="Link to your website or social media profile"
                    />
                  </div>

                  <div className="flex items-start space-x-3">
                    <input
                      type="checkbox"
                      id="terms-agreement"
                      name="terms-agreement"
                      checked={formData['terms-agreement']}
                      onChange={handleInputChange}
                      required
                      className="w-4 h-4 text-emerald-600 border-gray-300 rounded focus:ring-emerald-500"
                    />
                    <label htmlFor="terms-agreement" className="text-sm text-gray-700">
                      I agree that my tip can be published on EcoTechPicks and understand that 
                      submission doesn't guarantee publication. I confirm this is my original content.
                    </label>
                  </div>

                  {error && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                      <div className="flex items-center">
                        <i className="ri-error-warning-line text-red-600 mr-2"></i>
                        <p className="text-red-600 text-sm">{error}</p>
                      </div>
                    </div>
                  )}

                  <div className="flex flex-col sm:flex-row gap-4 pt-6">
                    <button
                      type="submit"
                      disabled={isSubmitting || formData['tip-description'].length > 500}
                      className="bg-emerald-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap cursor-pointer"
                    >
                      {isSubmitting ? (
                        <span className="flex items-center justify-center space-x-2">
                          <i className="ri-loader-4-line animate-spin"></i>
                          <span>Submitting...</span>
                        </span>
                      ) : (
                        'Submit Tip'
                      )}
                    </button>
                    <Link
                      href="/tips"
                      className="border border-emerald-600 text-emerald-600 px-8 py-4 rounded-lg font-semibold hover:bg-emerald-50 transition-colors whitespace-nowrap cursor-pointer text-center"
                    >
                      Back to Tips
                    </Link>
                  </div>
                </fieldset>
              </form>
            )}
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Submission Guidelines
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                To ensure quality content for our community, please follow these guidelines when submitting your tips.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6">
                <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mb-4">
                  <i className="ri-lightbulb-line text-white text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Be Practical
                </h3>
                <p className="text-gray-600">
                  Share tips that are actionable and can be implemented by our readers. Include specific steps and expected outcomes.
                </p>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6">
                <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mb-4">
                  <i className="ri-leaf-line text-white text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Focus on Impact
                </h3>
                <p className="text-gray-600">
                  Explain how your tip benefits the environment and helps create a more sustainable lifestyle.
                </p>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6">
                <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mb-4">
                  <i className="ri-check-line text-white text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Original Content
                </h3>
                <p className="text-gray-600">
                  Submit only original content that you've personally tested or experienced. Credit any sources you reference.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}


'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-emerald-50 border-t border-emerald-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center">
                <i className="ri-leaf-line text-white text-lg"></i>
              </div>
              <span className="text-2xl font-bold text-emerald-800 font-pacifico">EcoTechPicks</span>
            </div>
            <p className="text-gray-600 mb-4 max-w-md">
              Your trusted source for eco-friendly tech reviews and sustainable living tips. 
              Join our community of environmentally conscious tech enthusiasts.
            </p>
            <div className="flex space-x-4">
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-emerald-600 hover:text-emerald-700 cursor-pointer">
                <i className="ri-twitter-fill text-xl"></i>
              </a>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-emerald-600 hover:text-emerald-700 cursor-pointer">
                <i className="ri-facebook-fill text-xl"></i>
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-emerald-600 hover:text-emerald-700 cursor-pointer">
                <i className="ri-instagram-fill text-xl"></i>
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="text-emerald-600 hover:text-emerald-700 cursor-pointer">
                <i className="ri-youtube-fill text-xl"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Links</h3>
            <div className="space-y-2">
              <Link href="/" className="block text-gray-600 hover:text-emerald-600 cursor-pointer">
                Home
              </Link>
              <Link href="/tips" className="block text-gray-600 hover:text-emerald-600 cursor-pointer">
                Green Tips
              </Link>
              <Link href="/about" className="block text-gray-600 hover:text-emerald-600 cursor-pointer">
                About
              </Link>
              <Link href="/contact" className="block text-gray-600 hover:text-emerald-600 cursor-pointer">
                Contact
              </Link>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Categories</h3>
            <div className="space-y-2">
              <Link href="/reviews" className="block text-gray-600 hover:text-emerald-600 cursor-pointer">
                Tech Reviews
              </Link>
              <Link href="/tips" className="block text-gray-600 hover:text-emerald-600 cursor-pointer">
                Green Tips
              </Link>
              <Link href="/community" className="block text-gray-600 hover:text-emerald-600 cursor-pointer">
                Community
              </Link>
              <Link href="/submit-tip" className="block text-gray-600 hover:text-emerald-600 cursor-pointer">
                Submit Tip
              </Link>
            </div>
          </div>
        </div>
        
        <div className="border-t border-emerald-200 mt-8 pt-8 text-center">
          <p className="text-gray-600">
            © 2024 EcoTechPicks. All rights reserved. Built with sustainability in mind.
          </p>
        </div>
      </div>
    </footer>
  );
}

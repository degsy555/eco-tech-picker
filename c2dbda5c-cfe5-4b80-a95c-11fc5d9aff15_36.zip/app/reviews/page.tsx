
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ReviewCard from '@/components/ReviewCard';
import Link from 'next/link';
import { useState } from 'react';

export default function ReviewsPage() {
  const [selectedCategory, setSelectedCategory] = useState("All");

  const allReviews = [
    {
      title: "Solar Power Bank 20000mAh - Endless Energy for Your Adventures",
      excerpt: "This solar power bank delivers reliable renewable energy for all your devices. Perfect for camping, hiking, and emergency situations. Features fast charging and weather-resistant design.",
      rating: 5,
      category: "Solar Energy",
      imageUrl: "https://readdy.ai/api/search-image?query=modern%20solar%20power%20bank%20portable%20charger%20lying%20on%20wooden%20table%20with%20green%20plants%20in%20background%2C%20clean%20white%20background%2C%20eco-friendly%20technology%2C%20professional%20product%20photography&width=400&height=250&seq=solar-powerbank-1&orientation=landscape",
      date: "March 15, 2024",
      author: "Sarah Green"
    },
    {
      title: "Bamboo Wireless Charging Pad - Sustainable Tech That Actually Works",
      excerpt: "Made from 100% sustainable bamboo, this wireless charger combines eco-consciousness with cutting-edge technology. Fast charging capabilities with zero plastic waste.",
      rating: 4,
      category: "Sustainable Materials",
      imageUrl: "https://readdy.ai/api/search-image?query=bamboo%20wireless%20charging%20pad%20with%20smartphone%20on%20top%2C%20wooden%20desk%20setting%20with%20small%20green%20plants%2C%20minimalist%20eco-friendly%20design%2C%20warm%20natural%20lighting&width=400&height=250&seq=bamboo-charger-1&orientation=landscape",
      date: "March 12, 2024",
      author: "Mike Chen"
    },
    {
      title: "Energy-Efficient Smart Thermostat - Save Money While Saving the Planet",
      excerpt: "This AI-powered thermostat learns your habits and optimizes energy usage automatically. Reduced our energy bill by 30% while maintaining perfect comfort levels.",
      rating: 5,
      category: "Energy Efficient",
      imageUrl: "https://readdy.ai/api/search-image?query=modern%20smart%20thermostat%20mounted%20on%20white%20wall%20with%20green%20living%20room%20background%2C%20digital%20display%20showing%20temperature%2C%20eco-friendly%20home%20technology%2C%20clean%20minimal%20design&width=400&height=250&seq=smart-thermostat-1&orientation=landscape",
      date: "March 10, 2024",
      author: "Emma Wilson"
    },
    {
      title: "Recycled Plastic Bluetooth Speaker - Great Sound, Greater Impact",
      excerpt: "Built entirely from ocean plastic waste, this speaker delivers premium audio quality while helping clean our oceans. Waterproof design perfect for outdoor adventures.",
      rating: 4,
      category: "Sustainable Materials",
      imageUrl: "https://readdy.ai/api/search-image?query=bluetooth%20speaker%20made%20from%20recycled%20plastic%20sitting%20on%20beach%20sand%20with%20ocean%20waves%20in%20background%2C%20eco-friendly%20design%2C%20sustainable%20technology%2C%20blue%20and%20green%20color%20scheme&width=400&height=250&seq=recycled-speaker-1&orientation=landscape",
      date: "March 8, 2024",
      author: "David Park"
    },
    {
      title: "Wind-Powered Phone Charger - Harness Nature's Energy",
      excerpt: "This innovative portable wind turbine can charge your devices using natural wind power. Perfect for camping and outdoor activities where solar isn't available.",
      rating: 4,
      category: "Wind Energy",
      imageUrl: "https://readdy.ai/api/search-image?query=portable%20wind%20turbine%20charger%20device%20on%20camping%20table%20with%20mountains%20in%20background%2C%20outdoor%20adventure%20gear%2C%20green%20renewable%20energy%20technology%2C%20natural%20landscape%20setting&width=400&height=250&seq=wind-charger-1&orientation=landscape",
      date: "March 6, 2024",
      author: "Tom Rodriguez"
    },
    {
      title: "Biodegradable Phone Case - Protection That Doesn't Harm the Planet",
      excerpt: "Made from plant-based materials, this phone case offers excellent protection while being completely biodegradable. Available in multiple colors and phone models.",
      rating: 4,
      category: "Sustainable Materials",
      imageUrl: "https://readdy.ai/api/search-image?query=biodegradable%20phone%20case%20made%20from%20plant%20materials%20on%20wooden%20surface%20with%20green%20leaves%20around%2C%20eco-friendly%20phone%20accessories%2C%20sustainable%20technology%2C%20natural%20textures&width=400&height=250&seq=bio-case-1&orientation=landscape",
      date: "March 4, 2024",
      author: "Rachel Kim"
    },
    {
      title: "Energy Harvesting Keyboard - Type Your Way to Clean Energy",
      excerpt: "This revolutionary keyboard generates energy from your typing motions. The stored energy can power small devices or be fed back into your computer system.",
      rating: 5,
      category: "Energy Efficient",
      imageUrl: "https://readdy.ai/api/search-image?query=futuristic%20energy%20harvesting%20keyboard%20on%20modern%20desk%20with%20glowing%20energy%20indicators%2C%20high-tech%20workspace%2C%20sustainable%20technology%2C%20clean%20minimal%20design%20with%20green%20accent%20lights&width=400&height=250&seq=energy-keyboard-1&orientation=landscape",
      date: "March 2, 2024",
      author: "Jordan Lee"
    },
    {
      title: "Smart Water Bottle with Purification - Clean Water Anywhere",
      excerpt: "This smart water bottle uses UV-C light to purify water from any source. Track your hydration and reduce plastic waste with this innovative solution.",
      rating: 5,
      category: "Water Tech",
      imageUrl: "https://readdy.ai/api/search-image?query=smart%20water%20bottle%20with%20UV%20purification%20system%20on%20hiking%20trail%20with%20mountain%20stream%20in%20background%2C%20outdoor%20adventure%20gear%2C%20clean%20water%20technology%2C%20natural%20environment&width=400&height=250&seq=smart-bottle-1&orientation=landscape",
      date: "February 28, 2024",
      author: "Casey Morgan"
    },
    {
      title: "Recycled Aluminum Laptop Stand - Sustainable Workstation Upgrade",
      excerpt: "Crafted from 100% recycled aluminum, this laptop stand improves ergonomics while reducing environmental impact. Sleek design that complements any workspace.",
      rating: 4,
      category: "Sustainable Materials",
      imageUrl: "https://readdy.ai/api/search-image?query=aluminum%20laptop%20stand%20made%20from%20recycled%20materials%20on%20modern%20desk%20with%20plants%2C%20minimalist%20workspace%2C%20sustainable%20office%20accessories%2C%20clean%20professional%20design&width=400&height=250&seq=aluminum-stand-1&orientation=landscape",
      date: "February 26, 2024",
      author: "Alex Chen"
    }
  ];

  const categories = ["All", "Solar Energy", "Sustainable Materials", "Energy Efficient", "Wind Energy", "Water Tech"];

  const filteredReviews = selectedCategory === "All" 
    ? allReviews 
    : allReviews.filter(review => review.category === selectedCategory);

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="relative bg-gradient-to-r from-emerald-50 to-teal-50 py-20">
          <div 
            className="absolute inset-0 bg-cover bg-center opacity-10"
            style={{
              backgroundImage: `url('https://readdy.ai/api/search-image?query=eco-friendly%20technology%20reviews%20background%20with%20various%20sustainable%20gadgets%2C%20solar%20panels%2C%20green%20energy%20devices%2C%20modern%20tech%20workspace%2C%20environmental%20technology%20showcase&width=1200&height=600&seq=reviews-hero-1&orientation=landscape')`
            }}
          ></div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-5xl font-bold text-gray-900 mb-6">
                Complete Eco-Tech
                <span className="text-emerald-600"> Reviews</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                Comprehensive reviews of the latest sustainable technology products. 
                Find the perfect eco-friendly gadgets for your green lifestyle.
              </p>
              <div className="flex flex-wrap justify-center gap-4 mb-8">
                {categories.map((category, index) => (
                  <button 
                    key={index} 
                    onClick={() => setSelectedCategory(category)}
                    className={`px-6 py-2 rounded-full font-medium transition-colors whitespace-nowrap cursor-pointer ${
                      selectedCategory === category
                        ? 'bg-emerald-600 text-white hover:bg-emerald-700' 
                        : 'border border-emerald-600 text-emerald-600 hover:bg-emerald-50'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                {selectedCategory === "All" 
                  ? `All Reviews (${filteredReviews.length})` 
                  : `${selectedCategory} Reviews (${filteredReviews.length})`
                }
              </h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredReviews.map((review, index) => (
                <ReviewCard key={index} {...review} />
              ))}
            </div>
            
            {filteredReviews.length === 0 && (
              <div className="text-center py-12">
                <i className="ri-search-line text-4xl text-gray-400 mb-4"></i>
                <h3 className="text-xl font-semibold text-gray-600 mb-2">No reviews found</h3>
                <p className="text-gray-500">Try selecting a different category or check back later for new reviews.</p>
              </div>
            )}
            
            <div className="text-center mt-12">
              <p className="text-gray-600 mb-4">
                Want to see more reviews? Subscribe to our newsletter for the latest updates.
              </p>
              <Link href="/" className="bg-emerald-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer">
                Back to Home
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function AboutPage() {
  const teamMembers = [
    {
      name: "Sarah Green",
      role: "Founder & Editor-in-Chief",
      bio: "Environmental engineer with 10 years of experience in renewable energy. Passionate about making sustainable technology accessible to everyone.",
      image: "https://readdy.ai/api/search-image?query=professional%20woman%20with%20brown%20hair%20in%20modern%20office%20environment%2C%20eco-friendly%20workspace%20with%20plants%2C%20sustainable%20technology%20background%2C%20warm%20natural%20lighting%2C%20friendly%20smile&width=300&height=300&seq=sarah-green-1&orientation=squarish"
    },
    {
      name: "Mike Chen",
      role: "Senior Tech Reviewer",
      bio: "Former Silicon Valley engineer turned sustainability advocate. Expert in smart home technology and energy-efficient devices.",
      image: "https://readdy.ai/api/search-image?query=professional%20asian%20man%20with%20glasses%20in%20modern%20tech%20workspace%2C%20green%20technology%20equipment%20in%20background%2C%20sustainable%20innovation%20theme%2C%20clean%20professional%20portrait&width=300&height=300&seq=mike-chen-1&orientation=squarish"
    },
    {
      name: "Emma Wilson",
      role: "Green Living Specialist",
      bio: "Certified sustainability consultant and author of 'Living Green in the Digital Age'. Specializes in eco-friendly lifestyle technology.",
      image: "https://readdy.ai/api/search-image?query=professional%20woman%20with%20blonde%20hair%20in%20sustainable%20office%20setting%2C%20eco-friendly%20technology%20and%20plants%20around%2C%20natural%20lighting%2C%20confident%20professional%20portrait&width=300&height=300&seq=emma-wilson-1&orientation=squarish"
    },
    {
      name: "David Park",
      role: "Community Manager",
      bio: "Digital marketing expert with a focus on environmental causes. Builds bridges between tech companies and eco-conscious consumers.",
      image: "https://readdy.ai/api/search-image?query=professional%20man%20with%20dark%20hair%20in%20modern%20green%20workspace%2C%20sustainable%20technology%20setup%2C%20friendly%20approachable%20expression%2C%20eco-friendly%20office%20environment&width=300&height=300&seq=david-park-1&orientation=squarish"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="relative bg-gradient-to-r from-emerald-50 to-teal-50 py-20">
          <div 
            className="absolute inset-0 bg-cover bg-center opacity-10"
            style={{
              backgroundImage: `url('https://readdy.ai/api/search-image?query=sustainable%20technology%20company%20office%20with%20eco-friendly%20workspace%2C%20green%20plants%2C%20solar%20panels%2C%20modern%20clean%20environment%2C%20team%20collaboration%2C%20environmental%20mission%20focus&width=1200&height=600&seq=about-hero-1&orientation=landscape')`
            }}
          ></div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-5xl font-bold text-gray-900 mb-6">
                About 
                <span className="text-emerald-600">EcoTechPicks</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                We're on a mission to make sustainable technology accessible and understandable for everyone. 
                Join us in creating a greener future through informed tech choices.
              </p>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-6">
                  Our Story
                </h2>
                <p className="text-gray-600 mb-6">
                  Founded in 2022, EcoTechPicks emerged from a simple observation: while sustainable technology 
                  was rapidly advancing, consumers struggled to find reliable, comprehensive reviews that focused 
                  on environmental impact alongside performance.
                </p>
                <p className="text-gray-600 mb-6">
                  Our team of environmental engineers, tech experts, and sustainability advocates came together 
                  to bridge this gap. We test products not just for their features, but for their real-world 
                  impact on energy consumption, material sustainability, and environmental benefits.
                </p>
                <p className="text-gray-600">
                  Today, we're proud to serve over 150,000 monthly readers who trust our reviews and tips 
                  to make informed decisions about eco-friendly technology.
                </p>
              </div>
              
              <div className="relative">
                <img 
                  src="https://readdy.ai/api/search-image?query=sustainable%20technology%20testing%20lab%20with%20eco-friendly%20devices%2C%20solar%20panels%2C%20energy%20meters%2C%20green%20plants%2C%20modern%20clean%20workspace%2C%20environmental%20technology%20research&width=600&height=400&seq=our-story-1&orientation=landscape"
                  alt="Our sustainable tech testing lab"
                  className="rounded-lg shadow-lg object-cover object-top w-full h-96"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Our Mission & Values
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Everything we do is guided by our commitment to environmental sustainability and technological innovation.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6 text-center">
                <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-leaf-line text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  Environmental First
                </h3>
                <p className="text-gray-600">
                  We evaluate every product through the lens of environmental impact, from manufacturing to disposal.
                </p>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6 text-center">
                <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-shield-check-line text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  Honest Reviews
                </h3>
                <p className="text-gray-600">
                  Our reviews are unbiased, thorough, and based on real-world testing by our expert team.
                </p>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6 text-center">
                <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-community-line text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  Community Driven
                </h3>
                <p className="text-gray-600">
                  We learn from our community and incorporate reader feedback into our reviews and recommendations.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Meet Our Team
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Our diverse team of experts brings together decades of experience in technology, 
                environmental science, and sustainable living.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {teamMembers.map((member, index) => (
                <div key={index} className="text-center">
                  <img 
                    src={member.image}
                    alt={member.name}
                    className="w-32 h-32 rounded-full mx-auto mb-4 object-cover object-top"
                  />
                  <h3 className="text-xl font-semibold text-gray-900 mb-1">
                    {member.name}
                  </h3>
                  <p className="text-emerald-600 font-medium mb-3">
                    {member.role}
                  </p>
                  <p className="text-gray-600 text-sm">
                    {member.bio}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 bg-emerald-600">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-white mb-4">
              Join Our Mission
            </h2>
            <p className="text-emerald-100 text-lg mb-8 max-w-2xl mx-auto">
              Whether you're a tech enthusiast, environmental advocate, or simply someone who wants to make 
              better choices, we invite you to be part of our community.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/community" className="bg-white text-emerald-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-50 transition-colors whitespace-nowrap cursor-pointer">
                Join Community
              </Link>
              <Link href="/contact" className="border border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer">
                Contact Us
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

'use client';

import { useState } from 'react';
import { saveSubscription } from '../lib/newsletter-storage';

export default function NewsletterSignup() {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsSubmitting(true);
    setError('');

    try {
      // Save to local storage
      saveSubscription(email);

      // Also submit to API as backup
      const response = await fetch('https://readdy.ai/api/form-submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          formId: 'eco-newsletter-signup',
          email: email,
        }),
      });

      // Show success regardless of API response since we saved locally
      setIsSubmitted(true);
      setEmail('');
    } catch (error) {
      // Even if API fails, we still saved locally
      console.error('API submission error:', error);
      setIsSubmitted(true);
      setEmail('');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSubmitted) {
    return (
      <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-6 text-center">
        <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <i className="ri-check-line text-white text-2xl"></i>
        </div>
        <h3 className="text-lg font-semibold text-emerald-800 mb-2">
          Thank you for subscribing!
        </h3>
        <p className="text-emerald-600">
          You'll receive our green living updates and eco-tech reviews soon.
        </p>
        <button
          onClick={() => setIsSubmitted(false)}
          className="mt-4 text-emerald-600 hover:text-emerald-700 text-sm cursor-pointer"
        >
          Subscribe another email
        </button>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-lg p-6">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <i className="ri-mail-line text-white text-2xl"></i>
        </div>
        <h3 className="text-2xl font-bold text-gray-900 mb-2">
          Stay Green, Stay Informed
        </h3>
        <p className="text-gray-600">
          Get weekly eco-tech reviews and sustainable living tips delivered to your inbox.
        </p>
      </div>

      <form id="eco-newsletter-signup" onSubmit={handleSubmit} className="space-y-4">
        <div>
          <input
            type="email"
            name="email"
            placeholder="Enter your email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-3 border border-emerald-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
            required
          />
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-center">
            <p className="text-red-600 text-sm">{error}</p>
          </div>
        )}

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-emerald-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap cursor-pointer"
        >
          {isSubmitting ? (
            <span className="flex items-center justify-center space-x-2">
              <i className="ri-loader-4-line animate-spin"></i>
              <span>Subscribing...</span>
            </span>
          ) : (
            <span className="flex items-center justify-center space-x-2">
              <i className="ri-mail-send-line"></i>
              <span>Subscribe for Free</span>
            </span>
          )}
        </button>
      </form>

      <p className="text-xs text-gray-500 text-center mt-4">
        No spam, unsubscribe anytime. We respect your privacy.
      </p>
    </div>
  );
}

'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function SmartThermostatReview() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="py-16 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <Link href="/reviews" className="text-emerald-600 hover:text-emerald-700 cursor-pointer">
                ← Back to Reviews
              </Link>
            </div>
            
            <article>
              <header className="mb-8">
                <div className="flex items-center space-x-4 mb-4">
                  <span className="bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full text-sm font-medium">
                    Energy Efficient
                  </span>
                  <span className="text-gray-500">March 10, 2024</span>
                  <span className="text-gray-500">by Emma Wilson</span>
                </div>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                  Energy-Efficient Smart Thermostat - Save Money While Saving the Planet
                </h1>
                <div className="flex items-center space-x-2 mb-6">
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <i key={i} className="ri-star-fill text-yellow-400 text-lg"></i>
                    ))}
                  </div>
                  <span className="text-gray-600 font-medium">5.0/5</span>
                </div>
              </header>
              
              <div className="mb-8">
                <img 
                  src="https://readdy.ai/api/search-image?query=modern%20smart%20thermostat%20with%20sleek%20digital%20display%20mounted%20on%20white%20wall%2C%20contemporary%20living%20room%20background%20with%20plants%2C%20showing%20temperature%20and%20energy%20savings%20data%2C%20minimalist%20smart%20home%20design&width=800&height=500&seq=smart-thermostat-detail-1&orientation=landscape"
                  alt="Smart Thermostat"
                  className="w-full h-96 object-cover object-top rounded-lg shadow-lg"
                />
              </div>
              
              <div className="prose prose-lg max-w-none">
                <p className="text-xl text-gray-600 mb-6">
                  After six months of use, this AI-powered smart thermostat has not only reduced 
                  our energy consumption by 30% but also maintained perfect comfort levels 
                  throughout our home. It's a game-changer for sustainable living.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Intelligent Learning System</h2>
                <p className="mb-4">
                  What sets this thermostat apart is its advanced machine learning capabilities. 
                  Within the first week, it began recognizing our daily patterns, automatically 
                  adjusting temperature before we even realized we needed it. The system learns 
                  from multiple factors including occupancy, weather forecasts, and energy rates.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Key Features</h2>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>AI-powered learning algorithms adapt to your schedule</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>Geofencing automatically adjusts when you're away</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>Weather integration optimizes heating/cooling</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>Energy usage reports with cost-saving recommendations</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>Compatible with most HVAC systems</span>
                  </li>
                </ul>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Energy Savings Results</h2>
                <p className="mb-4">
                  Our detailed analysis over six months shows remarkable results:
                </p>
                <div className="bg-emerald-50 p-6 rounded-lg mb-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-3xl font-bold text-emerald-600">30%</div>
                      <div className="text-gray-700">Energy Reduction</div>
                    </div>
                    <div>
                      <div className="text-3xl font-bold text-emerald-600">$47</div>
                      <div className="text-gray-700">Monthly Savings</div>
                    </div>
                    <div>
                      <div className="text-3xl font-bold text-emerald-600">2.1 tons</div>
                      <div className="text-gray-700">CO2 Prevented</div>
                    </div>
                  </div>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Installation and Setup</h2>
                <p className="mb-4">
                  Installation was surprisingly straightforward. The included step-by-step guide 
                  and companion app made the process manageable for most homeowners. The device 
                  detected our HVAC system automatically and guided us through the wiring process.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Smart Home Integration</h2>
                <p className="mb-4">
                  The thermostat integrates seamlessly with major smart home platforms including 
                  Google Home, Amazon Alexa, and Apple HomeKit. Voice control works flawlessly, 
                  and the mobile app provides detailed insights and remote control capabilities.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Pros and Cons</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-green-800 mb-2">Pros</h3>
                    <ul className="text-green-700 space-y-1 text-sm">
                      <li>• Significant energy savings</li>
                      <li>• Intuitive learning system</li>
                      <li>• Excellent mobile app</li>
                      <li>• Wide compatibility</li>
                      <li>• Professional installation support</li>
                    </ul>
                  </div>
                  <div className="bg-red-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-red-800 mb-2">Cons</h3>
                    <ul className="text-red-700 space-y-1 text-sm">
                      <li>• Higher initial investment</li>
                      <li>• Requires stable WiFi connection</li>
                      <li>• Learning period of 1-2 weeks</li>
                    </ul>
                  </div>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Final Verdict</h2>
                <p className="mb-6">
                  This smart thermostat represents the perfect marriage of comfort, convenience, 
                  and environmental responsibility. The energy savings alone justify the investment, 
                  while the enhanced comfort and convenience are valuable bonuses.
                </p>
                
                <div className="bg-emerald-50 p-6 rounded-lg mb-8">
                  <h3 className="font-semibold text-emerald-800 mb-2">Our Rating: 5/5 Stars</h3>
                  <p className="text-emerald-700">
                    "A must-have for anyone serious about reducing their environmental impact 
                    while maintaining comfort. The ROI is clear and the technology is impressive."
                  </p>
                </div>
              </div>
            </article>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
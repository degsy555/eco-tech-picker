
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { useState } from 'react';
import { saveAccountToStorage } from '@/lib/account-storage';

export default function RegisterPage() {
  const [formData, setFormData] = useState({
    'full-name': '',
    'email': '',
    'password': '',
    'confirm-password': '',
    'interests': [] as string[],
    'newsletter': false,
    'terms': false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState('');
  const [passwordStrength, setPasswordStrength] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordsMatch, setPasswordsMatch] = useState(true);

  const interestOptions = [
    'Solar Energy',
    'Smart Home',
    'Energy Saving',
    'Recycling',
    'Water Conservation',
    'DIY Projects',
    'Sustainable Materials',
    'Digital Habits'
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;

    if (name === 'interests') {
      const currentInterests = formData.interests;
      const updatedInterests = checked 
        ? [...currentInterests, value]
        : currentInterests.filter(interest => interest !== value);

      setFormData(prev => ({
        ...prev,
        interests: updatedInterests
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: type === 'checkbox' ? checked : value
      }));
    }

    if (name === 'password') {
      checkPasswordStrength(value);
      checkPasswordMatch(value, formData['confirm-password']);
    }

    if (name === 'confirm-password') {
      checkPasswordMatch(formData.password, value);
    }
  };

  const checkPasswordMatch = (password: string, confirmPassword: string) => {
    if (confirmPassword === '') {
      setPasswordsMatch(true);
      return;
    }
    setPasswordsMatch(password === confirmPassword);
  };

  const isValidEmail = (email: string) => {
    const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
    return emailRegex.test(email);
  };

  const checkPasswordStrength = (password: string) => {
    if (password.length < 6) {
      setPasswordStrength('weak');
    } else if (password.length < 10 || !/(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)/.test(password)) {
      setPasswordStrength('medium');
    } else {
      setPasswordStrength('strong');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!isValidEmail(formData.email)) {
      setError('Please enter a valid email address.');
      return;
    }

    if (formData.password !== formData['confirm-password']) {
      setError('Passwords do not match.');
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    if (!formData.terms) {
      setError('Please agree to the terms and conditions.');
      return;
    }

    setIsSubmitting(true);

    try {
      const accountData = {
        fullName: formData['full-name'],
        email: formData.email,
        interests: formData.interests,
        newsletter: formData.newsletter
      };

      saveAccountToStorage(accountData);

      const submitData = new URLSearchParams();
      submitData.append('full-name', formData['full-name']);
      submitData.append('email', formData.email);
      submitData.append('interests', formData.interests.join(', '));
      submitData.append('newsletter', formData.newsletter ? 'true' : 'false');
      submitData.append('terms', formData.terms ? 'true' : 'false');

      fetch('https://readdy.ai/api/form-submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: submitData.toString(),
      }).catch(() => {
        // Silently handle API errors since we're storing locally
      });

      setIsSubmitted(true);
      setFormData({
        'full-name': '',
        'email': '',
        'password': '',
        'confirm-password': '',
        'interests': [],
        'newsletter': false,
        'terms': false
      });
      setPasswordStrength('');
      setPasswordsMatch(true);

      window.scrollTo({ top: 0, behavior: 'smooth' });

    } catch (error: any) {
      console.error('Registration error:', error);
      if (error.message && error.message.includes('already exists')) {
        setError('An account with this email already exists. Please use a different email address.');
      } else {
        setError('Unable to create account. Please try again.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const getPasswordStrengthColor = () => {
    switch (passwordStrength) {
      case 'weak': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      case 'strong': return 'bg-green-500';
      default: return 'bg-gray-300';
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <main>
        <section className="relative bg-gradient-to-r from-emerald-50 to-teal-50 py-20">
          <div 
            className="absolute inset-0 bg-cover bg-center opacity-10"
            style={{
              backgroundImage: `url('https://readdy.ai/api/search-image?query=person%20creating%20account%20on%20laptop%20with%20green%20technology%20interface%2C%20sustainable%20community%20signup%2C%20eco-friendly%20registration%20form%2C%20modern%20workspace%20with%20plants%20and%20renewable%20energy%20symbols&width=1200&height=600&seq=register-hero-1&orientation=landscape')`
            }}
          ></div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-5xl font-bold text-gray-900 mb-6">
                Join Our Green Tech
                <span className="text-emerald-600"> Community</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                Create your account to connect with eco-conscious individuals and access exclusive content, 
                community features, and personalized recommendations.
              </p>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
            {isSubmitted ? (
              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-8 text-center">
                <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-check-line text-white text-2xl"></i>
                </div>
                <h2 className="text-2xl font-bold text-emerald-600 mb-4">Welcome to EcoTechPicks!</h2>
                <p className="text-emerald-600 mb-6">
                  Your account has been created successfully. You can now access all community features and start exploring our eco-friendly content.
                </p>
                <div className="space-y-4">
                  <Link href="/community" className="bg-emerald-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer inline-block">
                    Explore Community
                  </Link>
                  <div>
                    <Link href="/tips" className="text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer">
                      Browse Tips →
                    </Link>
                  </div>
                </div>
              </div>
            ) : (
              <form id="registration-form" onSubmit={handleSubmit} className="bg-white rounded-lg shadow-sm border border-emerald-100 p-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Create Your Account</h2>

                <fieldset disabled={isSubmitting} className="space-y-6">
                  <div>
                    <label htmlFor="full-name" className="block text-sm font-medium text-gray-700 mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      id="full-name"
                      name="full-name"
                      value={formData['full-name']}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm disabled:opacity-50"
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className={`w-full px-4 py-3 border rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm disabled:opacity-50 ${
                        formData.email && !isValidEmail(formData.email) 
                          ? 'border-red-300 focus:border-red-500 focus:ring-red-500' 
                          : 'border-gray-300'
                      }`}
                      placeholder="Enter your email address"
                    />
                    {formData.email && !isValidEmail(formData.email) && (
                      <p className="mt-1 text-sm text-red-600">Please enter a valid email address</p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                      Password *
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? "text" : "password"}
                        id="password"
                        name="password"
                        value={formData.password}
                        onChange={handleInputChange}
                        required
                        className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm disabled:opacity-50"
                        placeholder="Create a strong password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer"
                      >
                        <i className={`${showPassword ? 'ri-eye-off-line' : 'ri-eye-line'} text-gray-400 hover:text-gray-600`}></i>
                      </button>
                    </div>
                    {formData.password && (
                      <div className="mt-2">
                        <div className="flex items-center space-x-2">
                          <div className="flex-1 bg-gray-200 rounded-full h-1">
                            <div 
                              className={`h-1 rounded-full transition-all duration-300 ${getPasswordStrengthColor()}`}
                              style={{ width: passwordStrength === 'weak' ? '33%' : passwordStrength === 'medium' ? '66%' : '100%' }}
                            ></div>
                          </div>
                          <span className="text-xs text-gray-500 capitalize">{passwordStrength}</span>
                        </div>
                        <p className="mt-1 text-xs text-gray-500">
                          Password strength: Use 10+ characters with uppercase, lowercase, and numbers for best security
                        </p>
                      </div>
                    )}
                  </div>

                  <div>
                    <label htmlFor="confirm-password" className="block text-sm font-medium text-gray-700 mb-2">
                      Confirm Password *
                    </label>
                    <div className="relative">
                      <input
                        type={showConfirmPassword ? "text" : "password"}
                        id="confirm-password"
                        name="confirm-password"
                        value={formData['confirm-password']}
                        onChange={handleInputChange}
                        required
                        className={`w-full px-4 py-3 pr-12 border rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm disabled:opacity-50 ${
                          formData['confirm-password'] && !passwordsMatch 
                            ? 'border-red-300 focus:border-red-500 focus:ring-red-500' 
                            : 'border-gray-300'
                        }`}
                        placeholder="Confirm your password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer"
                      >
                        <i className={`${showConfirmPassword ? 'ri-eye-off-line' : 'ri-eye-line'} text-gray-400 hover:text-gray-600`}></i>
                      </button>
                    </div>
                    {formData['confirm-password'] && !passwordsMatch && (
                      <p className="mt-1 text-sm text-red-600">Passwords do not match</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-3">
                      Interests (Select all that apply)
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      {interestOptions.map((interest) => (
                        <label key={interest} className="flex items-center space-x-2 cursor-pointer">
                          <input
                            type="checkbox"
                            name="interests"
                            value={interest}
                            checked={formData.interests.includes(interest)}
                            onChange={handleInputChange}
                            className="w-4 h-4 text-emerald-600 border-gray-300 rounded focus:ring-emerald-500"
                          />
                          <span className="text-sm text-gray-700">{interest}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <input
                      type="checkbox"
                      id="newsletter"
                      name="newsletter"
                      checked={formData.newsletter}
                      onChange={handleInputChange}
                      className="w-4 h-4 text-emerald-600 border-gray-300 rounded focus:ring-emerald-500"
                    />
                    <label htmlFor="newsletter" className="text-sm text-gray-700">
                      Subscribe to our newsletter for the latest green tech tips and community updates
                    </label>
                  </div>

                  <div className="flex items-start space-x-3">
                    <input
                      type="checkbox"
                      id="terms"
                      name="terms"
                      checked={formData.terms}
                      onChange={handleInputChange}
                      required
                      className="w-4 h-4 text-emerald-600 border-gray-300 rounded focus:ring-emerald-500"
                    />
                    <label htmlFor="terms" className="text-sm text-gray-700">
                      I agree to the Terms of Service and Privacy Policy. I understand that my information 
                      will be used to provide community features and personalized content.
                    </label>
                  </div>

                  {error && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                      <div className="flex items-center">
                        <i className="ri-error-warning-line text-red-600 mr-2"></i>
                        <p className="text-red-600 text-sm">{error}</p>
                      </div>
                    </div>
                  )}

                  <div className="flex flex-col sm:flex-row gap-4 pt-6">
                    <button
                      type="submit"
                      disabled={isSubmitting || !passwordsMatch || (formData.email && !isValidEmail(formData.email))}
                      className="flex-1 bg-emerald-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap cursor-pointer text-center"
                    >
                      {isSubmitting ? (
                        <span className="flex items-center justify-center space-x-2">
                          <i className="ri-loader-4-line animate-spin"></i>
                          <span>Creating Account...</span>
                        </span>
                      ) : (
                        <span className="flex items-center justify-center space-x-2">
                          <i className="ri-user-add-line"></i>
                          <span>Create Account</span>
                        </span>
                      )}
                    </button>
                    <Link
                      href="/community"
                      className="border border-emerald-600 text-emerald-600 px-8 py-4 rounded-lg font-semibold hover:bg-emerald-50 transition-colors whitespace-nowrap cursor-pointer text-center"
                    >
                      Back to Community
                    </Link>
                  </div>
                </fieldset>
              </form>
            )}
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Community Benefits
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Join thousands of eco-conscious individuals and unlock exclusive features designed to help you live more sustainably.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6 text-center">
                <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-user-star-line text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Personalized Content
                </h3>
                <p className="text-gray-600">
                  Get customized tips and recommendations based on your interests and sustainability goals.
                </p>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6 text-center">
                <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-message-3-line text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Community Access
                </h3>
                <p className="text-gray-600">
                  Participate in discussions, share your projects, and connect with like-minded individuals.
                </p>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-emerald-100 p-6 text-center">
                <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-gift-line text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Exclusive Features
                </h3>
                <p className="text-gray-600">
                  Access premium content, early previews, and special community events and challenges.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function BambooWirelessChargerReview() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <section className="py-16 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <Link href="/reviews" className="text-emerald-600 hover:text-emerald-700 cursor-pointer">
                ← Back to Reviews
              </Link>
            </div>
            
            <article>
              <header className="mb-8">
                <div className="flex items-center space-x-4 mb-4">
                  <span className="bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full text-sm font-medium">
                    Sustainable Materials
                  </span>
                  <span className="text-gray-500">March 12, 2024</span>
                  <span className="text-gray-500">by Mike Chen</span>
                </div>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                  Bamboo Wireless Charging Pad - Sustainable Tech That Actually Works
                </h1>
                <div className="flex items-center space-x-2 mb-6">
                  <div className="flex items-center space-x-1">
                    {[...Array(4)].map((_, i) => (
                      <i key={i} className="ri-star-fill text-yellow-400 text-lg"></i>
                    ))}
                    <i className="ri-star-line text-yellow-400 text-lg"></i>
                  </div>
                  <span className="text-gray-600 font-medium">4.0/5</span>
                </div>
              </header>
              
              <div className="mb-8">
                <img 
                  src="https://readdy.ai/api/search-image?query=bamboo%20wireless%20charging%20pad%20with%20iPhone%20charging%20on%20top%2C%20minimalist%20desk%20setup%20with%20small%20plants%2C%20natural%20wood%20texture%20visible%2C%20warm%20ambient%20lighting%2C%20eco-friendly%20design%20aesthetic&width=800&height=500&seq=bamboo-charger-detail-1&orientation=landscape"
                  alt="Bamboo Wireless Charging Pad"
                  className="w-full h-96 object-cover object-top rounded-lg shadow-lg"
                />
              </div>
              
              <div className="prose prose-lg max-w-none">
                <p className="text-xl text-gray-600 mb-6">
                  In a world dominated by plastic tech accessories, this bamboo wireless charger 
                  stands out as a beautiful, functional piece that doesn't compromise on performance 
                  while staying true to sustainable principles.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Design and Build Quality</h2>
                <p className="mb-4">
                  The charging pad is crafted from 100% sustainable bamboo, sourced from responsibly 
                  managed forests. The natural wood grain gives each unit a unique appearance, making 
                  it as much a decorative piece as a functional accessory. The smooth finish feels 
                  premium and resists scratches and water damage.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Technical Specifications</h2>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>15W fast wireless charging for compatible devices</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>Qi-certified for universal compatibility</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>Built-in temperature control and overcharge protection</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>LED indicator for charging status</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-emerald-600 mt-1"></i>
                    <span>Non-slip base prevents sliding</span>
                  </li>
                </ul>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Charging Performance</h2>
                <p className="mb-4">
                  The charger delivers consistent 15W power to compatible devices, matching the 
                  performance of plastic alternatives. iPhone 12 and newer models charged from 
                  20% to 80% in approximately 90 minutes during our testing. The temperature 
                  remained reasonable throughout, never getting uncomfortably warm.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Sustainability Factor</h2>
                <p className="mb-4">
                  What impressed us most was the complete lifecycle thinking. The packaging is 
                  made from recycled cardboard, the charging cable is covered in recycled fabric, 
                  and the company offers a take-back program when the device reaches end-of-life.
                </p>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Pros and Cons</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-green-800 mb-2">Pros</h3>
                    <ul className="text-green-700 space-y-1 text-sm">
                      <li>• Beautiful, natural design</li>
                      <li>• 100% sustainable materials</li>
                      <li>• Fast charging performance</li>
                      <li>• Universal Qi compatibility</li>
                      <li>• Excellent build quality</li>
                    </ul>
                  </div>
                  <div className="bg-red-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-red-800 mb-2">Cons</h3>
                    <ul className="text-red-700 space-y-1 text-sm">
                      <li>• Premium price point</li>
                      <li>• Limited color options</li>
                      <li>• Requires careful positioning</li>
                    </ul>
                  </div>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Final Verdict</h2>
                <p className="mb-6">
                  The Bamboo Wireless Charging Pad proves that sustainable technology doesn't mean 
                  sacrificing performance. It's a premium product that justifies its price through 
                  superior materials, thoughtful design, and reliable functionality.
                </p>
                
                <div className="bg-emerald-50 p-6 rounded-lg mb-8">
                  <h3 className="font-semibold text-emerald-800 mb-2">Our Rating: 4/5 Stars</h3>
                  <p className="text-emerald-700">
                    "A beautiful, functional piece that seamlessly blends sustainability with 
                    technology. Perfect for eco-conscious consumers who appreciate quality design."
                  </p>
                </div>
              </div>
            </article>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}